<?php include 'includes/header.php'; ?>
<?php include 'includes/banner.php'; ?>
<?php include 'includes/navigation.php'; ?></div>
<div class="row corpus">
<div class="col-md-3 asideColumn hidden-xs hidden-sm">
	<aside class="contentCol">

	</aside>
</div>
<div class="col-md-9 sectionContent">
	<section class="contentCol">

	</section>
</div>
</div>
<?php include 'includes/footer.php'; ?>
<?php ob_end_flush();?>