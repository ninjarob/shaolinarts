        <nav class="navbar navbar-inverse" role="navigation">
          <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand hidden-md hidden-lg hidden-sm" href="#">Shaolin Arts</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="currentEvents.php">Current Events</a></li>
                <li><a href="locations.php">Locations</a></li>
                <li><a href="contactUs.php">Contact Us</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">More Information<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li><a href="about.php">About Shaolin Arts</a></li>
                    <li class="divider"></li>
                    <li><a href="historyAndPhilosophy.php">History &amp; Philosophy</a></li>
                    <li class="divider"></li>
                    <li><a href="calssInformation.php">Class Information</a></li>
                    <li class="divider"></li>
                    <li><a href="kungFu.php">Kung Fu</a></li>
                    <li><a href="taiChi.php">Tai Chi</a></li>
                    <li><a href="selfDefence.php">Self Defence</a></li>
                    <li><a href="mixedMartialArts.php#">Mixed Martial Arts</a></li>
                    <li><a href="fitness.php">Fitness</a></li>
                    <li class="divider"></li>
                    <li><a href="faq.php">FAQ</a></li>
                  </ul>
                </li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <?php session_start(); if(!isset($_SESSION['sessionRole'])){ ?>
                  <li><a href="login.php">Login</a></li>
                <?php } else { ?>
                  <li><a href="logout.php">Logout</a></li>
                <?php } ?>
              </ul>
            </div><!-- /.navbar-collapse -->
          </div><!-- /.container-fluid -->
        </nav>