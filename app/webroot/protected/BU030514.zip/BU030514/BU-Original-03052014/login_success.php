<?php
session_start();
if(!isset($_SESSION['username'])){
	header("location:index.php");
}

?>

<html>
<body>
	<br />
	<h1>Login Success</h1>
	<a href="Logout.php">Log Out</a>
</body>
</html>