<?php

	require 'includes/connect.php';
	require 'includes/varDef.php';

// echo "$sessionRole, $sessionRoleStudio, $sessionstatusSession, $sessionrankSession, $sessionrankDateSession, $sessiontaiChiStatusSession, $sessionTaiChiRankSession, $sessionTaiChiRankDateSession";

	// To protect MySQL injection (more detail about MySQL injection)

	$un = stripslashes($un);
	$pw = stripslashes($pw);
	$un = mysql_real_escape_string($un);
	$pw = mysql_real_escape_string($pw);

	$sql="SELECT * FROM $tbl_name WHERE un='$un' and pw='$pw'";
	$result=mysql_query($sql);

	$array = mysql_fetch_array($result);
	$role=$array['role'];
	$studioRole=$array['studioRole'];

	$status = $array['status'];
	$rank = $array['rank'];
	$studio = $array['studio'];

	$rankDate = $array['rankDate'];
	//$studio = strtotime($rankDate);
	//$rankDate = date('Ymd', $rankDate);

	$taiChiStatus = $array['taiChiStatus'];
	$TaiChiRank = $array['TaiChiRank'];
	$taiChiStudio = $array['taiChiStudio'];

	$TaiChiRankDate = $array['TaiChiRankDate'];
	//$TaiChiRankDate = strtotime($TaiChiRankDate);
	//$TaiChiRankDate = date('Ymd', $TaiChiRankDate);

	$todayDate = date('Ymd');

	// $KungFuFutureDate = $rankDate + 10000;
	// $TaiChiFutureDate = $TaiChiRankDate + 10000;
	// $TaiChiFutureDateBlk = $rankDate + 20000;
	// $KungFuFutureDateBlk = $TaiChiRankDate + 20000;
	// $MngrInsFutureDate = $rankDate + 20000;
	// $DistManagerFutureDate = $rankDate + 40000;


	// Mysql_num_row is counting table row


	$count=mysql_num_rows($result);


	if($un){

			if($count==1){

				if($status==0 || $taiChiStatus==0){

					session_start();

					$_SESSION['sessionRole'] = $role;
					$_SESSION['sessionRoleStudio'] = $studioRole;

					$_SESSION['statusSession'] = $status;
					$_SESSION['rankSession'] = $rank;
					$_SESSION['rankDateSession'] = $rankDate;
					$_SESSION['StudioSession'] = $studio;

					$_SESSION['taiChiStatusSession'] = $taiChiStatus;
					$_SESSION['TaiChiRankSession'] = $TaiChiRank;
					$_SESSION['TaiChiRankDateSession'] = $TaiChiRankDate;
					$_SESSION['TaiChiStudioSession'] = $taiChiStudio;

					if($role=='student' or $role=='insCollege'){

						// if($todayDate<=$KungFuFutureDate || $todayDate<=$TaiChiFutureDate || $sessionRole=='instructor' && $todayDate<=$MngrInsFutureDate || $sessionRole=='manager' && $todayDate<=$MngrInsFutureDate || $sessionRole=='districtMa' && $todayDate<=$DistManagerFutureDate || $rank>11 && $rank<23 && $todayDate<=$KungFuFutureDateBlk || $TaiChiRank>11 && $TaiChiRank<23 && $todayDate<=$TaiChiFutureDateBlk ){

							header("location:http://shaolinarts.com/pdf_viewer.php");

						// }else{

						// 	$message="I am sorry, but it seems that your access to this content has expired, try giving the office a call.";

						// }

					}else{

						header("location:admin.php");

					}

				}else{

					$message="I am sorry, but you do not seem to have access to this content, try giving the office a call.";

				}

			}else{

				$message="Either your user name or password are incorrect, why don't you give it another try.";

			}



	}else{

		$message="Please enter your username and password";

	}



ob_end_flush();



?>



<!DOCTYPE html>

<html>

	<head>

	<meta charset="utf-8">

	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Log in</title>

	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.css" />

	<link href="shaolinarts.min.css" rel="stylesheet" type="text/css" media="all" />

	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>

	<script src="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.js"></script>

</head>

<body>



<form name="form1" method="post" action="login.php"  data-ajax="false">

<div style="width: 500px; margin: 200px auto;" data-role="content">



		<div data-role="header">

			<h1>Log In</h1>

		</div>





	    <ul data-role="listview" data-inset="true">

			<li>

				<?php echo $message; ?>

			</li>

	        <li data-role="fieldcontain">

	            <label for="name" style="display: block; float: left; width: 100px;">Username:</label>

	            <input name="un" type="text" id="myusername" data-mini="true" data-inline="true" />

	        </li>

	        <li data-role="fieldcontain">

	            <label for="name" style="display: block; float: left; width: 100px;">Password:</label>

	            <input name="pw" type="password" id="mypassword"  data-mini="true" data-inline="true" />

	        </li>

	        <li>

				<input type="submit" name="Submit" value="Login"  data-mini="true" data-inline="true" data-icon="plus" />

			</li>

			<li><a href="http://shaolinarts.com/passwordManagement.php" ajax="false">Did you forget your user name or password?</a></li>
			<li><a href="http://shaolinarts.com/newMember.php" ajax="false">Is this the first time at the website?</a></li>

		</ul>





		</div>

		</form>



<script type="text/javascript">

	$(document).ready(function() {

		$('#myusername').focus();

	});

</script>



</body>

</html>



