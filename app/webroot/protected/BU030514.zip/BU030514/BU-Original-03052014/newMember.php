<?php
	require 'includes/connect.php';
	require 'includes/varDef.php';

	$name = stripslashes($name);
	$lastName = stripslashes($lastName);
	$email = stripslashes($email);

	$message = "Please fill all the fields to create a new user name and password (The information is case sensitive)";

	if($name && $lastName && $email && $birthday){
		$sql="SELECT * FROM $tbl_name WHERE name='$name' and lastName='$lastName' and email='$email' and birthday='$birthday'";
		$result=mysql_query($sql);
		$array = mysql_fetch_array($result);
		$count=mysql_num_rows($result);
		$un=$array["un"];
		$id=$array["id"];
		if($count==1){
			if($un){
				$message = "You already have a User Name and Password, if you have forgotten your user name or password, please click on \"Did you forget your password? \"";
			}else{
				$passwordKey = rand();
				mysql_query("UPDATE `$tbl_name` SET passwordKey='$passwordKey' WHERE id='$id';") or die(mysql_error("Database Error"));
				header("location:http://shaolinarts.com/newUnPwSetup.php?K=$passwordKey");
			}
		}else{
			$message = "We are unable to find you, please make sure you entered your information accurately or give the studio a call. (Remember that it is case sensitive)";
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>New Member</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.css" />
	<link href="shaolinarts.min.css" rel="stylesheet" type="text/css" media="all" />
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.js"></script>
</head>
<body>
<form name="form1" method="post" action="newMember.php"  data-ajax="false">
	<div style="width: 500px; margin: 200px auto;" data-role="content">
		<div data-role="header">
			<h1>New Member Access</h1>
		</div>
		<ul data-role="listview" data-inset="true">

			<?php
				if($message){
					echo "
						<li>
							<label style\"color: #f00;\">".$message."</label>
						</li>
						<!-- <li>
							<label style\"color: #f00;\">".$name."</label>
						</li>
						<li>
							<label style\"color: #f00;\">".$lastName."</label>
						</li>
						<li>
							<label style\"color: #f00;\">".$email."</label>
						</li>
						<li>
							<label style\"color: #f00;\">".$birthday."</label>
						</li> -->
					";
				}
			?>

			<?php
					if($un){
			?>

			<li data-role="fieldcontain">
				<a href="login.php">Go to the login page</a>
			</li>
			<li data-role="fieldcontain">
				<a href="passwordManagement.php">Did you just forgot your password?</a>
			</li>

			<?php
					}else{
			?>

			<li data-role="fieldcontain">
				<label for="name" style="display: block; float: left; width: 150px;">Name:</label>
				<input name="name" type="text" id="myusername" data-mini="true" data-inline="true" />
			</li>
			<li data-role="fieldcontain">
				<label for="lastName" style="display: block; float: left; width: 150px;">Last Name:</label>
				<input name="lastName" type="text" id="myusername" data-mini="true" data-inline="true" />
			</li>
			<li data-role="fieldcontain">
				<label for="email" style="display: block; float: left; width: 150px;">Email Address:</label>
				<input name="email" type="text" id="myusername" data-mini="true" data-inline="true" />
			</li>
			<li data-role="fieldcontain">
				<label for="birthday" style="display: block; float: left; width: 150px; font-weight: bold;">Birthday:</label>
				<input name="birthday" type="date" id="birthday" data-mini="true"  data-inline="true" />
			</li>
			<li>
				<input type="submit" name="Submit" value="Submit"  data-mini="true" data-inline="true" data-icon="plus" />
			</li>
			<li data-role="fieldcontain">
				<a href="http://shaolinarts.com/passwordManagement.php">Did you just forget your password?</a>
			</li>

			<?php
					}
			?>

		</ul>
	</div>
</form>

<script type="text/javascript">
	$(document).ready(function() {
		$('#myusername').focus();
	});
</script>
</body>
</html>