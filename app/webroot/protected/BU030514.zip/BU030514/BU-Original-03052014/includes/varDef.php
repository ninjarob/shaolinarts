<?php

	$delete=$_GET['delete'];

	$id=$_POST['id'];
	$role=$_POST['role'];
	$studioRole=$_POST['studioRole'];

	$name=$_POST['name'];
	$lastName=$_POST['lastName'];
	$homePhone=$_POST['homePhone'];
	$cellPhone=$_POST['cellPhone'];
	$workPhone=$_POST['workPhone'];
	$email=$_POST['email'];
	$addres=$_POST['addres'];
	$city=$_POST['city'];
	$state=$_POST['state'];
	$zip=$_POST['zip'];
	$birthday=$_POST['birthday'];
	$spouseGuardian=$_POST['spouseGuardian'];
	$sgPhone=$_POST['sgPhone'];
	$sgCellPhone=$_POST['sgCellPhone'];
	$startDate=$_POST['startDate'];

	$program=$_POST['program'];

	$status=$_POST['status'];
	$studio=$_POST['studio'];
	$rank=$_POST['rank'];
	$rankDate=$_POST['rankDate'];
	$dueDate=$_POST['dueDate'];
	$lessonType=$_POST['lessonType'];
	$longTermProgram=$_POST['longTermProgram'];

	$taiChiStatus=$_POST['taiChiStatus'];
	$taiChiStudio=$_POST['taiChiStudio'];
	$TaiChiRank=$_POST['TaiChiRank'];
	$TaiChiRankDate=$_POST['TaiChiRankDate'];
	$taiChiDueDate=$_POST['taiChiDueDate'];
	$TaiChiLessonType=$_POST['TaiChiLessonType'];
	$TaiChiProgram=$_POST['TaiChiProgram'];

	$studentID=$_POST['studentID'];
	$ice1=$_POST['ice1'];
	$ice1Phone=$_POST['ice1Phone'];
	$ice1CellPhone=$_POST['ice1CellPhone'];
	$ice2=$_POST['ice2'];
	$ice2Phone=$_POST['ice2Phone'];
	$ice2CellPhone=$_POST['ice2CellPhone'];
	$ice3=$_POST['ice3'];
	$ice3Phone=$_POST['ice3Phone'];
	$ice3CellPhone=$_POST['ice3CellPhone'];
	$un=$_POST['un'];
	$pw=$_POST['pw'];
	$notes=$_POST['notes'];
?>