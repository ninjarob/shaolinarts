<?php
				echo "
					<li>"
						."<a href=\"view_student.php?id=".$id."\">
							<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px; color: #55f; font-weight: bold;\">".$fname." ".$lname."</span>
							<span style= \"padding-right: 15px; font-weight: normal; font-size: 13px;\">".floor($age)."</span>
				";
			if($status==0){
					echo "
							<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><strong>Kung Fu:</strong></span>
					";



				if($rank==23){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth White</u></em></span>";};
				if($rank==24){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth Yellow</u></em></span>";};
				if($rank==25){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth Orange</u></em></span>";};
				if($rank==26){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth Purple</u></em></span>";};
				if($rank==27){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth Blue</u></em></span>";};
				if($rank==28){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth Blue Advanced</u></em></span>";};
				if($rank==29){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth Green</u></em></span>";};
				if($rank==30){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth Green Advanced</u></em></span>";};
				if($rank==31){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth Red</u></em></span>";};
				if($rank==32){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth Brown</u></em></span>";};
				if($rank==33){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth Brown Advanced</u></em></span>";};
				if($rank==1){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>White</u></em></span>";};
				if($rank==2){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Yellow</u></em></span>";};
				if($rank==3){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Orange</u></em></span>";};
				if($rank==4){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Purple</u></em></span>";};
				if($rank==5){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Blue</u></em></span>";};
				if($rank==6){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Blue Advanced</u></em></span>";};
				if($rank==7){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Green</u></em></span>";};
				if($rank==8){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Green Advanced</u></em></span>";};
				if($rank==9){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Red</u></em></span>";};
				if($rank==10){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Brown</u></em></span>";};
				if($rank==11){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Brown Advanced</u></em></span>";};
				if($rank==12){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Sidi</u></em></span>";};
				if($rank==13){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Sidi Dai Lou</u></em></span>";};
				if($rank==14){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Si Hing</u></em></span>";};
				if($rank==15){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Si Hing Dai Lou</u></em></span>";};
				if($rank==16){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Sisuk</u></em></span>";};
				if($rank==17){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Sisuk Dai Lou</u></em></span>";};
				if($rank==18){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Sifu</u></em></span>";};
				if($rank==19){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Si Bok</u></em></span>";};
				if($rank==20){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Si Gung</u></em></span>";};
				if($rank==21){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Si Tai Gung</u></em></span>";};
				if($rank==22){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Si Jo</u></em></span>";};

				if($studio==1){
					echo "
							<span style= \"padding-right: 15px; font-weight: normal; font-size: 13px;\"> Glendale</span>
					";
				}
				if($studio==2){
					echo "
							<span style= \"padding-right: 15px; font-weight: normal; font-size: 13px;\"> Sandy</span>
					";
				}
				if($studio==3){
					echo "
							<span style= \"padding-right: 15px; font-weight: normal; font-size: 13px;\"> Taylorsvile</span>
					";
				}

			}

			if($taiChiStatus==0){

					echo "
							<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><strong>Tai Chi:</strong></span>
					";
					if($TaiChiRank==0){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>White</u></em></span>";};
					if($TaiChiRank==23){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Si Jo</u></em></span>";};
					if($TaiChiRank==5){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth Gold</u></em></span>";};
					if($TaiChiRank==6){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth Blue</u></em></span>";};
					if($TaiChiRank==7){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Youth Red</u></em></span>";};
					if($TaiChiRank==1){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Gold</u></em></span>";};
					if($TaiChiRank==2){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Blue</u></em></span>";};
					if($TaiChiRank==3){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Red</u></em></span>";};
					if($TaiChiRank==12){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Sidi</u></em></span>";};
					if($TaiChiRank==13){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Sidi Dai Lou</u></em></span>";};
					if($TaiChiRank==14){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Si Hing</u></em></span>";};
					if($TaiChiRank==15){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Si Hing Dai Lou</u></em></span>";};
					if($TaiChiRank==16){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Sisuk</u></em></span>";};
					if($TaiChiRank==17){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Sisuk Dai Lou</u></em></span>";};
					if($TaiChiRank==18){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Sifu</u></em></span>";};
					if($TaiChiRank==19){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Si Bok</u></em></span>";};
					if($TaiChiRank==20){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Si Gung</u></em></span>";};
					if($TaiChiRank==21){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Si Tai Gung</u></em></span>";};
					if($TaiChiRank==22){echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"><em><u>Si Jo</u></em></span>";};
				if($taiChiStudio==1){
					echo "
							<span style= \"padding-right: 15px; font-weight: normal; font-size: 13px;\"><strong></strong> Glendale</span>
					";
				}
				if($taiChiStudio==2){
					echo "
							<span style= \"padding-right: 15px; font-weight: normal; font-size: 13px;\"><strong></strong> Sandy</span>
					";
				}
				if($taiChiStudio==3){
					echo "
							<span style= \"padding-right: 15px; font-weight: normal; font-size: 13px;\"><strong></strong> Taylorsvile</span>
					";
				}


			}




			if($status==1 && $taiChiStatus==1){ echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"> <strong>Not Active</strong></span> ";}
			if(($status==2 && $taiChiStatus==1) || ($status==1 && $taiChiStatus==2)){ echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"> <strong>Not Active</strong></span> ";}
			if($status==2 && $taiChiStatus==2){ echo "<span style= \"padding-right: 3px; font-weight: normal; font-size: 13px;\"> <strong>Non Student</strong></span> ";}

			echo"</a>";


			if($sessionRole!='instructor'){
				echo "
					<a href=\"edit_user.php?id=".$id."\" data-icon=\"gear\">Edit</a>
				";
			}
			echo"</li>";
?>