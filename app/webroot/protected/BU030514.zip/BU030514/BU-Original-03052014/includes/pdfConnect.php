<?php
	$host="localhost"; // Host name 
	$username="varegoco_sa"; // Mysql username 
	$password="DdTUx@nJt_*9"; // Mysql password 
	$db_name="varegoco_shaolinarts"; // Database name 
	$tbl_name="PDFmanuals"; // Table name 
	
	
	// Connect to server and select databse.
	mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
	mysql_select_db("$db_name")or die("cannot select DB");

	// To protect MySQL injection (more detail about MySQL injection)
//	$sql="SELECT * FROM $tbl_name";
//	$PDFresult=mysql_query($sql);

	// Mysql_num_row is counting table row

//	$PDFcount=mysql_num_rows($PDFresult);
	
	$FileNamesResults = mysql_query("SELECT PDFfileName FROM $tbl_name");
	$PDFfileNames = Array();
	
	while ($PDFnameRow = mysql_fetch_array($FileNamesResults, MYSQL_ASSOC)) {
		$PDFfileNames[] =  $PDFnameRow['PDFfileName'];  
	}

	$PDFrankResults = mysql_query("SELECT PDFrankLevel FROM $tbl_name");
	$PDFrank = Array();
	
	while ($PDFrankRow = mysql_fetch_array($PDFrankResults, MYSQL_ASSOC)) {
		$PDFrank[] =  $PDFrankRow['PDFrankLevel'];  
	}

	$PDFprogramResults = mysql_query("SELECT PDFprogram FROM $tbl_name");
	$PDFprog = Array();
	
	while ($PDFprogRow = mysql_fetch_array($PDFprogramResults, MYSQL_ASSOC)) {
		$PDFprog[] =  $PDFprogRow['PDFprogram'];  
	}	

	$PDFtitleResults = mysql_query("SELECT pdfTitle FROM $tbl_name");
	$PDFtitles = Array();
	
	while ($PDFtitleRow = mysql_fetch_array($PDFtitleResults, MYSQL_ASSOC)) {
		$PDFtitles[] =  $PDFtitleRow['pdfTitle'];  
	}		
	
	
	$pdfInfo = array($PDFfileNames,$PDFrank,$PDFprog,$PDFtitles);
	
	//echo $pdfInfo[3][0];

	mysql_close();

?>
