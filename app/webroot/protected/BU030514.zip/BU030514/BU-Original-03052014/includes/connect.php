<?php
	$host="localhost"; // Host name
	$username="varegoco_sa"; // Mysql username
	$password="DdTUx@nJt_*9"; // Mysql password
	$db_name="varegoco_shaolinarts"; // Database name
	$tbl_name="students"; // Table name


	// Connect to server and select databse.
	mysql_connect("$host", "$username", "$password")or die("cannot connect");
	mysql_select_db("$db_name")or die("cannot select DB");

	// To protect MySQL injection (more detail about MySQL injection)
	$sql="SELECT * FROM $tbl_name";
	$result=mysql_query($sql);

	// Mysql_num_row is counting table row

	$count=mysql_num_rows($result);
	$array = mysql_fetch_array($result);

	// Define $myusername and $mypassword
	$id=$_GET['id'];

	if($id){
		// To protect MySQL injection (more detail about MySQL injection)
		$sql="SELECT * FROM $tbl_name WHERE id='$id'";
		$result=mysql_query($sql);

		// Mysql_num_row is counting table row
		$count=mysql_num_rows($result);

		$array = mysql_fetch_array($result);
	}
?>