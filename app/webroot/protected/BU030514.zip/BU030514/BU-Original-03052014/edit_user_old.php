<?php 
	require 'includes/check_session.php';
	$sessionRole = $_SESSION['sessionRole'];
	$sessionStudio = $_SESSION['sessionStudio'];
	require 'includes/roleCheck.php';	
	require 'includes/connect.php';	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Shaolin Arts</title>


<link href="p7curvitude/p7CRVboxes982_2col.css" rel="stylesheet" type="text/css" />
<link href="p7curvitude/p7CRV04.css" rel="stylesheet" type="text/css" />
<link href="p7pmm/p7PMMh13.css" rel="stylesheet" type="text/css" media="all" />

<meta name="viewport" content="width=device-width, initial-scale=1"> 
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.css" />
	<link href="shaolinarts.min.css" rel="stylesheet" type="text/css" media="all" />

	<link rel="stylesheet" href="validation/css/validationEngine.jquery.css" type="text/css"/>
	<link rel="stylesheet" href="validation/css/template.css" type="text/css"/>
<script type="text/javascript" src="p7pmm/p7PMMscripts.js"></script>

	
	<script src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.3.1/jquery.mobile-1.3.1.js"></script>

	<script src="validation/js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>
	<script src="validation/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>

<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#form1").validationEngine('attach');
		});
	</script>


<meta name="Keywords" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, Utah, Arizona, Marital Arts" />
<meta name="Description" content="Shaolin Arts is a family system of martial arts over 3,000 years old. Common western terms used to describe it would be Kung Fu, Tai Chi Chuan, Karate, Self Defense, Wushu, Animal Styles, Mixed Martial Arts, Chi Qi Gung or grappling. " />

<style type="text/css">
	
</style>




</head>
<body>
<div id="masthead" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, UtahArizonaMarital Arts">
  <div id="logo" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, UtahArizonaMarital Arts"><img src="images/logoanimbk.gif" alt="" width="982" height="160" /></div>
  <div id="navbar">
    <div id="navbar_inner">      
      <div id="navbar_inner2">
<div id="p7PMM_1" class="p7PMMh13">
  <ul class="p7PMM">
    <li><a href="../index.html">Home</a></li>
    <li><a href="pages/class-information.html">Class Information</a></li>
    <li><a href="pages/locations.html">Locations</a></li>
    <li><a ajax="false" href="pages/faq.html" data-ajax="false">FAQ</a></li>
    <li><a href="pages/events.html">Current Events</a></li>
    <li><a href="pages/areas-of-study.html">Areas of Study</a>
      <div>
        <ul>
          <li><a href="pages/kung-fu.html">Kung Fu</a></li>
          <li><a href="pages/tai-chi.html">Tai Chi</a></li>
          <li><a href="pages/self-defense.html">Self Defense</a></li>
          <li><a href="pages/mma.html">Mixed Martial Arts</a></li>
          <li><a href="pages/fitness.html">Fitness</a></li>
        </ul>
      </div>
    </li>
    <li><a href="pages/information.html">More Information</a>
      <div>
        <ul>
          <li><a href="pages/about-us.html">About Shaolin Arts</a></li>
          <li><a href="pages/events.html">Current Events</a></li>
          <li><a href="pages/class-information.html">Class Information</a></li>
          <li><a href="pages/locations.html">Locations</a></li>
          <li><a ajax="false" href="pages/faq.html" data-ajax="false">FAQ</a></li>
          <li><a href="pages/contact.html">Contact Us</a></li>
          <li><a href="pages/history.html">History &amp; Philosophy</a></li>
        </ul>
      </div>
    </li>
     <li><a href="Logout.php">Log Out</a></li>
  </ul>
  <div class="p7pmmclearfloat">&nbsp;</div>
  <!--[if lte IE 6]>
<style>
.p7PMMh13 ul ul li {float:left; clear: both; width: 100%;}.p7PMMh13 {text-align: left;}.p7PMMh13, .p7PMMh13 ul ul a {zoom: 1;}
.p7PMMh13 ul ul {border: 1px solid #fff; background-color: #F90 !important;}
.p7PMMh13 ul ul a, .p7PMMh13 ul ul li {background-image: none !important;}
.p7PMMh13 ul ul a {padding: 6px 12px !important;}
.p7PMMh13 ul ul a:hover {background-color: #010101 !important;}
.p7PMMh13 ul ul a.trig_open {background-color: #000 !important; color: #fff;}
.p7PMMh13 ul ul a.trig_closed {background-image: url(p7pmm/img/pmm_east_dark.gif) !important; background-repeat: no-repeat; background-position: right center;}
</style>
<![endif]-->
  <!--[if IE 5]>
<style>.p7PMMh13, .p7PMMh13 ul ul a {height: 1%; overflow: visible !important;} .p7PMMh13 {width: 100%;}</style>
<![endif]-->
  <!--[if IE 7]>
<style>.p7PMMh13, .p7PMMh13 a{zoom:1;}.p7PMMh13 ul ul li{float:left;clear:both;width:100%;}</style>
<![endif]-->
  <script type="text/javascript">
<!--
P7_PMMop('p7PMM_1',1,1,-10,-20,0,0,0,1,0,3,1,1,0,0);
//-->
  </script>
</div>
<div class="clearfloat">&nbsp;</div>
      </div>
    </div>
  </div>
</div>
  <div class="c2_982" id="columnwrapper">
  <div id="columntop">&nbsp;</div>
  <div id="c1">
    <div class="content">
      <h2 class="topZero"><img src="images/Chuan-Fa-char-with-English.jpg" width="137" height="569" alt="chaun fa" /></h2>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p><img src="images/Chen-character-englishBlackGold.jpg" width="144" height="576" alt="chen tai chi chuan" /></p>
    </div>
  </div>
  <div id="c2">
    <div class="content">
    	
    	
<h1>
	<?php
		if($id){
			echo "Edit User";
		}else{
			echo "Add User";
		}
	?>

</h1>

<p style="margin-bottom: 20px;"><a href="admin.php"  data-role="button" data-mini="true" data-inline="true" data-icon="back" >Return to the admin tool</a></p>
		
				<form name="form1" id="form1" method="post" data-ajax="false" action="update_processor.php">

					<ul data-role="listview" data-inset="true">
					
					<?php
						if($id){
							echo "
							<li  data-role=\"fieldcontain\">
								<input type=\"submit\" name=\"submit\" value=\"Update\">
							</li>
							";
						}
					?>

					
					
					
			<?php 
				
				if($id){
					$id=$array["id"];
					$role=$array["role"];
					$picture=$array["picture"];
					$name=$array["name"];
					$lastName=$array["lastName"];
					$homePhone=$array["homePhone"];
					$cellPhone=$array["cellPhone"];
					$workPhone=$array["workPhone"];
					$email=$array["email"];
					$addres=$array["addres"];
					$city=$array["city"];
					$state=$array["state"];

					if($state=="AL"){$state1="selected";}
					if($state=="AK"){$state2="selected";}
					if($state=="AZ"){$state3="selected";}
					if($state=="AR"){$state4="selected";}
					if($state=="CA"){$state5="selected";}
					if($state=="CO"){$state6="selected";}
					if($state=="CT"){$state7="selected";}
					if($state=="DE"){$state8="selected";}
					if($state=="DC"){$state9="selected";}
					if($state=="FL"){$state0="selected";}
					if($state=="GA"){$state10="selected";}
					if($state=="HI"){$state11="selected";}
					if($state=="ID"){$state12="selected";}
					if($state=="IL"){$state13="selected";}
					if($state=="IN"){$state14="selected";}
					if($state=="IA"){$state15="selected";}
					if($state=="KS"){$state17="selected";}
					if($state=="KY"){$state18="selected";}
					if($state=="LA"){$state19="selected";}
					if($state=="ME"){$state20="selected";}
					if($state=="MD"){$state21="selected";}
					if($state=="MA"){$state22="selected";}
					if($state=="MI"){$state23="selected";}
					if($state=="MN"){$state24="selected";}
					if($state=="MS"){$state25="selected";}
					if($state=="MO"){$state26="selected";}
					if($state=="MT"){$state27="selected";}
					if($state=="NE"){$state28="selected";}
					if($state=="NV"){$state29="selected";}
					if($state=="NH"){$state30="selected";}
					if($state=="NJ"){$state31="selected";}
					if($state=="NM"){$state32="selected";}
					if($state=="NY"){$state33="selected";}
					if($state=="NC"){$state34="selected";}
					if($state=="ND"){$state35="selected";}
					if($state=="OH"){$state36="selected";}
					if($state=="OK"){$state37="selected";}
					if($state=="OR"){$state38="selected";}
					if($state=="PA"){$state39="selected";}
					if($state=="RI"){$state40="selected";}
					if($state=="SC"){$state41="selected";}
					if($state=="SD"){$state42="selected";}
					if($state=="TN"){$state43="selected";}
					if($state=="TX"){$state44="selected";}
					if($state=="UT"){$state45="selected";}
					if($state=="VT"){$state46="selected";}
					if($state=="VA"){$state47="selected";}
					if($state=="WA"){$state48="selected";}
					if($state=="WV"){$state49="selected";}
					if($state=="WI"){$state40="selected";}
					if($state=="WY"){$state51="selected";}
					
					$zip=$array["zip"];
					$birthday=$array["birthday"];
					$spouseGuardian=$array["spouseGuardian"];
					$sgPhone=$array["sgPhone"];
					$sgCellPhone=$array["sgCellPhone"];
					$startDate=$array["startDate"];
					$dueDate=$array["dueDate"];
					$studio=$array["studio"];
					
					if($studio==1){$studio1="selected";}
					if($studio==2){$studio2="selected";}
					if($studio==3){$studio3="selected";}
					
					$program=$array["program"];
					if($program==1){$program1="selected";}
					if($program==2){$program2="selected";}
					if($program==3){$program3="selected";}
					
					$longTermProgram=$array["longTermProgram"];
					if($longTermProgram==1){$longTermProgram1="selected";}
					if($longTermProgram==2){$longTermProgram2="selected";}
					if($longTermProgram==3){$longTermProgram3="selected";}
					if($longTermProgram==4){$longTermProgram4="selected";}
					if($longTermProgram==5){$longTermProgram5="selected";}
					if($longTermProgram==6){$longTermProgram6="selected";}
					
					$TaiChiProgram=$array["TaiChiProgram"];
					if($TaiChiProgram==1){$TaiChiProgram1="selected";}
					if($TaiChiProgram==2){$TaiChiProgram2="selected";}
					if($TaiChiProgram==3){$TaiChiProgram3="selected";}
					if($TaiChiProgram==4){$TaiChiProgram4="selected";}
					if($TaiChiProgram==5){$TaiChiProgram5="selected";}
					if($TaiChiProgram==6){$TaiChiProgram6="selected";}

					$lessonType=$array["lessonType"];
					if($lessonType==1){$lessonType1="selected";}
					if($lessonType==2){$lessonType2="selected";}
					if($lessonType==3){$lessonType3="selected";}
					if($lessonType==4){$lessonType4="selected";}
					
					$TaiChiLessonType=$array["TaiChiLessonType"];
					if($TaiChiLessonType==1){$TaiChiLessonType1="selected";}
					if($TaiChiLessonType==2){$TaiChiLessonType2="selected";}
					if($TaiChiLessonType==3){$TaiChiLessonType3="selected";}
					if($TaiChiLessonType==4){$TaiChiLessonType4="selected";}
					
					$rank=$array["rank"];
					if($rank==1){$rank1="selected";}
					if($rank==2){$rank2="selected";}
					if($rank==3){$rank3="selected";}
					if($rank==4){$rank4="selected";}
					if($rank==5){$rank5="selected";}
					if($rank==6){$rank6="selected";}
					if($rank==7){$rank7="selected";}
					if($rank==8){$rank8="selected";}
					if($rank==9){$rank9="selected";}
					if($rank==10){$rank10="selected";}
					if($rank==11){$rank11="selected";}
					if($rank==12){$rank12="selected";}
					if($rank==13){$rank13="selected";}
					if($rank==14){$rank14="selected";}
					if($rank==15){$rank15="selected";}
					if($rank==16){$rank16="selected";}
					if($rank==17){$rank17="selected";}
					if($rank==18){$rank18="selected";}
					if($rank==19){$rank19="selected";}
					if($rank==20){$rank20="selected";}
					if($rank==21){$rank21="selected";}
					if($rank==22){$rank22="selected";}
					
					$TaiChiRank=$array["TaiChiRank"];
					if($TaiChiRank==1){$TaiChiRank1="selected";}
					if($TaiChiRank==2){$TaiChiRank2="selected";}
					if($TaiChiRank==3){$TaiChiRank3="selected";}
					if($TaiChiRank==4){$TaiChiRank4="selected";}

					
					
					$rankDate=$array["rankDate"];
					$status=$array["status"];
					if($status==0){$status1="selected";}
					if($status==1){$status2="selected";}
					if($status==2){$status3="selected";}
					
					$studentID=$array["studentID"];
					$ice1=$array["ice1"];
					$ice1Phone=$array["ice1Phone"];
					$ice1CellPhone=$array["ice1CellPhone"];
					$ice2=$array["ice2"];
					$ice2Phone=$array["ice2Phone"];
					$ice2CellPhone=$array["ice2CellPhone"];
					$ice3=$array["ice3"];
					$ice3Phone=$array["ice3Phone"];
					$ice3CellPhone=$array["ice3CellPhone"];
					$un=$array["un"];
					$pw=$array["pw"];
                    
                    
                    
					if($role=='student'){$role6="selected";}
					if($role=='instructor'){$role5="selected";}
                    if($role=='insCollege'){$role4="selected";}
                    if($role=='districtMa'){$role3="selected";}
					if($role=='manager'){$role2="selected";}
					if($role=='admin'){$role1="selected";}
					
					$notes=$array["notes"];
				}

				
				
				if($id){
					if($picture){
						echo "
							<li data-role=\"fieldcontain\" style=\"text-align: center; padding: 30px;\">
								<span><img src=\"upload/".$picture."\" style=\"width: 300px;\" /></span>
							</li>
						";
					}
					echo "
						<li data-role=\"fieldcontain\">
							<a href=\"image_upload.php?id=".$id."\">Update Image</a>
						</li>
					";
				}				


				echo "
				    <li data-role=\"fieldcontain\">
                        <label for=\"name\" style=\"display: block; float: left; width: 220px;\">Your are logged in as:</label><span>
                        ".$sessionRole."&nbsp;</span>
                    </li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">First Name:</label>
						<input name=\"name\" type=\"text\" class=\"validate[required,custom[onlyLetterNumber]] text-input\" id=\"name\" data-mini=\"true\" data-inline=\"true\" value=\"".$name."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Last Name:</label>
						<input name=\"lastName\" type=\"text\" id=\"lastName\" class=\"validate[required,custom[onlyLetterNumber]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$lastName."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Home Phone:</label>
						<input name=\"homePhone\" type=\"tel\" id=\"homePhone\" class=\"validate[custom[phone]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$homePhone."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Cell Phone:</label>
						<input name=\"cellPhone\" type=\"tel\" id=\"cellPhone\" class=\"validate[custom[phone]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$cellPhone."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Work Phone:</label>
						<input name=\"workPhone\" type=\"tel\" id=\"workPhone\" class=\"validate[custom[phone]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$workPhone."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">email:</label>
						<input name=\"email\" type=\"email\" id=\"email\"  class=\"validate[required,custom[email]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$email."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Address:</label>
						<input name=\"addres\" type=\"text\" id=\"addres\" class=\"validate[required,custom[onlyLetterNumber]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$addres."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">City:</label>
						<input name=\"city\" type=\"text\" id=\"city\" class=\"validate[required,custom[onlyLetterNumber]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$city."\"/>
					</li>
					
					
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">state:</label>
						<select name=\"state\" id=\"state\" data-mini=\"true\" data-inline=\"true\" name=\"State\">
								<option ".$state1." value=\"AL\">Alabama</option>
								<option ".$state2." value=\"AK\">Alaska</option>
								<option ".$state3." value=\"AZ\">Arizona</option>
								<option ".$state4." value=\"AR\">Arkansas</option>
								<option ".$state5." value=\"CA\">California</option>
								<option ".$state6." value=\"CO\">Colorado</option>
								<option ".$state7." value=\"CT\">Connecticut</option>
								<option ".$state8." value=\"DE\">Delaware</option>
								<option ".$state9." value=\"DC\">District Of Columbia</option>
								<option ".$state10." value=\"FL\">Florida</option>
								<option ".$state11." value=\"GA\">Georgia</option>
								<option ".$state12." value=\"HI\">Hawaii</option>
								<option ".$state13." value=\"ID\">Idaho</option>
								<option ".$state14." value=\"IL\">Illinois</option>
								<option ".$state15." value=\"IN\">Indiana</option>
								<option ".$state16." value=\"IA\">Iowa</option>
								<option ".$state17." value=\"KS\">Kansas</option>
								<option ".$state18." value=\"KY\">Kentucky</option>
								<option ".$state19." value=\"LA\">Louisiana</option>
								<option ".$state20." value=\"ME\">Maine</option>
								<option ".$state21." value=\"MD\">Maryland</option>
								<option ".$state22." value=\"MA\">Massachusetts</option>
								<option ".$state23." value=\"MI\">Michigan</option>
								<option ".$state24." value=\"MN\">Minnesota</option>
								<option ".$state25." value=\"MS\">Mississippi</option>
								<option ".$state26." value=\"MO\">Missouri</option>
								<option ".$state27." value=\"MT\">Montana</option>
								<option ".$state28." value=\"NE\">Nebraska</option>
								<option ".$state29." value=\"NV\">Nevada</option>
								<option ".$state30." value=\"NH\">New Hampshire</option>
								<option ".$state31." value=\"NJ\">New Jersey</option>
								<option ".$state32." value=\"NM\">New Mexico</option>
								<option ".$state33." value=\"NY\">New York</option>
								<option ".$state34." value=\"NC\">North Carolina</option>
								<option ".$state35." value=\"ND\">North Dakota</option>
								<option ".$state36." value=\"OH\">Ohio</option>
								<option ".$state37." value=\"OK\">Oklahoma</option>
								<option ".$state38." value=\"OR\">Oregon</option>
								<option ".$state39." value=\"PA\">Pennsylvania</option>
								<option ".$state40." value=\"RI\">Rhode Island</option>
								<option ".$state41." value=\"SC\">South Carolina</option>
								<option ".$state42." value=\"SD\">South Dakota</option>
								<option ".$state43." value=\"TN\">Tennessee</option>
								<option ".$state44." value=\"TX\">Texas</option>
								<option ".$state45." value=\"UT\">Utah</option>
								<option ".$state46." value=\"VT\">Vermont</option>
								<option ".$state47." value=\"VA\">Virginia</option>
								<option ".$state48." value=\"WA\">Washington</option>
								<option ".$state49." value=\"WV\">West Virginia</option>
								<option ".$state50." value=\"WI\">Wisconsin</option>
								<option ".$state51." value=\"WY\">Wyoming</option>
						</select>	
					</li>
					
					
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">zip:</label>
						<input name=\"zip\" type=\"text\" id=\"zip\" class=\"validate[required,custom[number]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$zip."\"/>
					</li>
					
					
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 200px;\">Birthday(YYYY-MM-DD):</label>
						<input name=\"birthday\" id=\"birthday\" class=\"validate[required,custom[date]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$birthday."\"/>
					</li>
					
					
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Spouse/Guardan:</label>
						<input name=\"spouseGuardian\" type=\"text\" id=\"spouseGuardian\" class=\"validate[custom[onlyLetterNumber]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$spouseGuardian."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Spouse/Guardian Phone:</label>
						<input name=\"sgPhone\" type=\"tel\" id=\"sgPhone\" data-mini=\"true\" class=\"validate[custom[phone]] text-input\" data-inline=\"true\" value=\"".$sgPhone."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Spouse/Guardian Cell Phone:</label>
						<input name=\"sgCellPhone\" type=\"tel\" id=\"sgCellPhone\" class=\"validate[custom[phone]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$sgCellPhone."\"/>
					</li>
					
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 200px;\">Start Date(YYYY-MM-DD):</label>
						<input name=\"startDate\" data-clear-btn=\"false\" class=\"validate[required,custom[date]] text-input\"  id=\"startDate\" data-mini=\"true\" data-inline=\"true\" value=\"".$startDate."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 200px;\">Due Date(YYYY-MM-DD):</label>
						<input name=\"dueDate\" id=\"dueDate\" class=\"validate[custom[date]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$dueDate."\"/>
					</li>
					";
					
					if($sessionRole=='admin'){
						echo "<li data-role=\"fieldcontain\">
							<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Studio:</label>
							<select name=\"studio\" data-mini=\"true\" data-inline=\"true\" >
							  <option ".$studio1." value=\"1\">Glendale, AZ</option>
							  <option ".$studio2." value=\"2\">Sandy, UT</option>
							  <option ".$studio3." value=\"3\">Taylorsville,UT</option>
							</select>			
						</li>";
					}
					
					if($sessionRole=='districtMa'){
						if($sessionStudio==1){
							echo "<li data-role=\"fieldcontain\">
								<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Studio:</label>
								<select name=\"studio\" data-mini=\"true\" data-inline=\"true\" >
								  <option ".$studio1." value=\"1\">Glendale, AZ</option>
								</select>			
							</li>";
						}
						if($sessionStudio==2 or $sessionStudio==3){
							echo "<li data-role=\"fieldcontain\">
								<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Studio:</label>
								<select name=\"studio\" data-mini=\"true\" data-inline=\"true\" >
									<option ".$studio2." value=\"2\">Sandy, UT</option>
									<option ".$studio3." value=\"3\">Taylorsville,UT</option>
								</select>			
							</li>";
						}
					}else{
						echo "<li data-role=\"fieldcontain\">
							<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Studio:</label>
							<select name=\"studio\" data-mini=\"true\" data-inline=\"true\" >
							  <option selected value=\"".$sessionStudio."\">
						";	  

						if($sessionStudio=='1'){
							echo "Glendale, AZ";
						}
						if($sessionStudio=='2'){
							echo "Sandy, UT";
						}
						if($sessionStudio=='3'){
							echo "Taylorsville,UT";
						}
						echo "	  
							  </option>
							</select>			
						</li>";
					}
					
					echo "
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Program:</label>
						<select name=\"program\" data-mini=\"true\" data-inline=\"true\">
							<option ".$program1." value=\"1\">Tai Chi</option>
							<option ".$program2." value=\"2\">Kung Fu</option>
							<option ".$program3." value=\"3\">Kung Fu and Tai Chi</option>
						</select>	
					</li>
					
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Kung Fu Program Term:</label>
						<select name=\"longTermProgram\" data-mini=\"true\" data-inline=\"true\">
							  <option ".$longTermProgram1." value=\"1\">BPS</option>
							  <option ".$longTermProgram2." value=\"2\">contract</option>
							  <option ".$longTermProgram3." value=\"3\">3 Months</option>
							  <option ".$longTermProgram4." value=\"4\">6 Months</option>
							  <option ".$longTermProgram5." value=\"5\">12 Months</option>
							  <option ".$longTermProgram6." value=\"6\">Month to Month</option>
						</select>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Tai Chi Program Term:</label>
						<select name=\"TaiChiProgram\" data-mini=\"true\" data-inline=\"true\">
							  <option ".$TaiChiProgram1." value=\"1\">BPS</option>
							  <option ".$TaiChiProgram2." value=\"2\">contract</option>
							  <option ".$TaiChiProgram3." value=\"3\">3 Months</option>
							  <option ".$TaiChiProgram4." value=\"4\">6 Months</option>
							  <option ".$TaiChiProgram5." value=\"5\">12 Months</option>
							  <option ".$TaiChiProgram6." value=\"6\">Month to Month</option>
						</select>
					</li>
					
					<li data-role=\"fieldcontain\">
						<label for=\"lessonType\" style=\"display: block; float: left; width: 150px;\">Kung Fu Lesson Type:</label>
						<select name=\"lessonType\" data-mini=\"true\" data-inline=\"true\">
							<option ".$lessonType1." value=\"1\">Group</option>
							<option ".$lessonType2." value=\"2\">Private</option>
							<option ".$lessonType3." value=\"3\">Accelerated</option>
							<option ".$lessonType4." value=\"4\">BSP</option>
						</select>	
					</li>
					
					<li data-role=\"fieldcontain\">
						<label for=\"TaiChiLessonType\" style=\"display: block; float: left; width: 150px;\">Tai Chi Lesson Type:</label>
						<select name=\"TaiChiLessonType\" data-mini=\"true\" data-inline=\"true\">
							<option ".$TaiChiLessonType1." value=\"1\">Group</option>
							<option ".$TaiChiLessonType2." value=\"2\">Private</option>
							<option ".$TaiChiLessonType3." value=\"3\">Accelerated</option>
							<option ".$TaiChiLessonType4." value=\"4\">BSP</option>
						</select>	
					</li>
					";
					
					

                    if($sessionRole=='districtMa' or $sessionRole=='admin'){
						echo "
						<li data-role=\"fieldcontain\">
							<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Kung Fu Rank:</label>
							<select name=\"rank\" data-mini=\"true\" data-inline=\"true\">
								<option ".$rank1." value=\"1\">White</option>
								<option ".$rank2." value=\"2\">Yellow</option>
								<option ".$rank3." value=\"3\">Orange</option>
								<option ".$rank4." value=\"4\">Purple</option>
								<option ".$rank5." value=\"5\">Blue</option>
								<option ".$rank6." value=\"6\">Blue Advanced</option>
								<option ".$rank7." value=\"7\">Green</option>
								<option ".$rank8." value=\"8\">Green Advanced</option>
								<option ".$rank9." value=\"9\">Red</option>
								<option ".$rank10." value=\"10\">Brown</option>
								<option ".$rank11." value=\"11\">Brown Advanced</option>
								<option ".$rank12." value=\"12\">Sidi</option>
								<option ".$rank13." value=\"13\">Sidi Dai Lou</option>
								<option ".$rank14." value=\"14\">Si Hing</option>
								<option ".$rank15." value=\"15\">Si Hing Dai Lou</option>
								<option ".$rank16." value=\"16\">Sisuk</option>
								<option ".$rank17." value=\"17\">Sisuk Dai Lou</option>
								<option ".$rank18." value=\"18\">Sifu</option>
								<option ".$rank19." value=\"19\">Si Bok</option>
								<option ".$rank20." value=\"20\">Si Gung</option>
								<option ".$rank21." value=\"21\">Si Tai Gung</option>
								<option ".$rank22." value=\"22\">Si Jo</option>
							</select>
						</li>

						<li data-role=\"fieldcontain\">
							<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Tai Chi Rank:</label>
							<select name=\"TaiChiRank\" data-mini=\"true\" data-inline=\"true\">
								<option ".$TaiChiRank1." value=\"1\">Gold Sash</option>
								<option ".$TaiChiRank2." value=\"2\">Blue Sash</option>
								<option ".$TaiChiRank3." value=\"3\">Red Sash</option>
								<option ".$TaiChiRank4." value=\"4\">Black Sash</option>
							</select>
						</li>					

					";
					}else{
						echo "
							<li data-role=\"fieldcontain\">
								<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Kung Fu Rank:</label>
								<select name=\"rank\" data-mini=\"true\" data-inline=\"true\">
									<option value=\"".$rank."\">
						";
											
							if($rank==1){ echo "White"; };
							if($rank==2){ echo "Yellow"; };
							if($rank==3){ echo "Orange"; };
							if($rank==4){ echo "Purple"; };
							if($rank==5){ echo "Blue"; };
							if($rank==6){ echo "Blue Advanced"; };
							if($rank==7){ echo "Green"; };
							if($rank==8){ echo "Green Advanced"; };
							if($rank==9){ echo "Red"; };
							if($rank==10){ echo "Brown"; };
							if($rank==11){ echo "Brown Advanced"; };
							if($rank==12){ echo "Sidi"; };
							if($rank==13){ echo "Sidi Dai Lou"; };
							if($rank==14){ echo "Si Hing"; };
							if($rank==15){ echo "Si Hing Dai Lou"; };
							if($rank==16){ echo "Sisuk"; };
							if($rank==17){ echo "Sisuk Dai Lou"; };
							if($rank==18){ echo "Sifu"; };
							if($rank==19){ echo "Si Bok"; };
							if($rank==20){ echo "Si Gung"; };
							if($rank==21){ echo "Si Tai Gung"; };
							if($rank==22){ echo "Si Jo"; };

						echo "
									</option>
								</select>
							</li>

							<li data-role=\"fieldcontain\">
								<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Tai Chi Rank:</label>
								<select name=\"TaiChiRank\" data-mini=\"true\" data-inline=\"true\">
									<option value=\"".$TaiChiRank."\">
						";
						
							if($TaiChiRank==1){ echo "Gold Sash"; };
							if($TaiChiRank==2){ echo "Red Sash"; };
							if($TaiChiRank==3){ echo "Blue Sash"; };
							if($TaiChiRank==4){ echo "Black Sash"; };

						echo "

									</option>
								</select>
							</li>					
						";
					}
					
					
					
                    
					echo "
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 250px;\">Kung Fu Rank Date(YYYY-MM-DD):</label>
						<input name=\"rankDate\" id=\"rankDate\"  class=\"validate[custom[date]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$rankDate."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 250px;\">Tai Chi Rank Date(YYYY-MM-DD):</label>
						<input name=\"TaiChiRankDate\" id=\"TaiChiRankDate\"  class=\"validate[custom[date]] text-input\" data-mini=\"true\" data-inline=\"true\" value=\"".$rankDate."\"/>
					</li>
					
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Status:</label>
						<select name=\"status\" data-mini=\"true\" data-inline=\"true\">
							<option ".$status1." value=\"0\">Active</option>
							<option ".$status2." value=\"1\">Not Active</option>
							<option ".$status3." value=\"2\">Non Student</option>
						</select>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Student ID:</label>
						<input name=\"studentID\" type=\"text\" id=\"studentID\" data-mini=\"true\" class=\"validate[custom[onlyLetterNumber]] text-input\" data-inline=\"true\" value=\"".$studentID."\"/>
					</li>
					
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 100px;\">ICE Name:</label>
						<input name=\"ice1\" type=\"text\" id=\"ice1\" data-mini=\"true\" class=\"validate[custom[onlyLetterNumber]] text-input\" data-inline=\"true\" value=\"".$ice1."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 100px;\">ICE Phone:</label>
						<input name=\"ice1Phone\" type=\"tel\" id=\"ice1Phone\" data-mini=\"true\" class=\"validate[custom[phone]] text-input\" data-inline=\"true\" value=\"".$ice1Phone."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 100px;\">ICE Cell Phone:</label>
						<input name=\"ice1CellPhone\" type=\"tel\" id=\"ice1CellPhone\" data-mini=\"true\" class=\"validate[custom[phone]] text-input\" data-inline=\"true\" value=\"".$ice1CellPhone."\"/>
					</li>
					
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 100px;\">ICE Name 2:</label>
						<input name=\"ice2\" type=\"text\" id=\"ice2\" data-mini=\"true\" class=\"validate[custom[onlyLetterNumber]] text-input\" data-inline=\"true\" value=\"".$ice2."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 100px;\">ICE Phone 2:</label>
						<input name=\"ice2Phone\" type=\"tel\" id=\"ice2Phone\" data-mini=\"true\" class=\"validate[custom[phone]] text-input\" data-inline=\"true\" value=\"".$ice2Phone."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 100px;\">ICE Cell Phone 2:</label>
						<input name=\"ice2CellPhone\" type=\"tel\" id=\"ice2CellPhone\" data-mini=\"true\" class=\"validate[custom[phone]] text-input\" data-inline=\"true\" value=\"".$ice2CellPhone."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 100px;\">ICE Name 3:</label>
						<input name=\"ice3\" type=\"text\" id=\"ice3\" data-mini=\"true\" class=\"validate[custom[onlyLetterNumber]] text-input\" data-inline=\"true\" value=\"".$ice3."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 100px;\">ICE Phone 3:</label>
						<input name=\"ice3Phone\" type=\"tel\" id=\"ice3Phone\" data-mini=\"true\" class=\"validate[custom[phone]] text-input\" data-inline=\"true\" value=\"".$ice3Phone."\"/>
					</li>
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 100px;\">ICE Cell Phone 3:</label>
						<input name=\"ice3CellPhone\" type=\"tel\" id=\"ice3CellPhone\" data-mini=\"true\" class=\"validate[custom[phone]] text-input\" data-inline=\"true\" value=\"".$ice3CellPhone."\"/>
					</li>
				";
                
                if($sessionRole=='admin'){
                    echo "	
    					<li data-role=\"fieldcontain\">
    						<label for=\"name\" style=\"display: block; float: left; width: 100px;\">User Name:</label>
    						<input name=\"un\" type=\"text\" id=\"un\" data-mini=\"true\" data-inline=\"true\" value=\"".$un."\"/>
    					</li>
    					<li data-role=\"fieldcontain\">
    						<label for=\"name\" style=\"display: block; float: left; width: 100px;\">Password:</label>
    						<input name=\"pw\" type=\"text\" id=\"pw\" data-mini=\"true\" data-inline=\"true\" value=\"".$pw."\"/>
    					</li>
    					
    				";
                }else{
                    echo "
                        <input type=\"hidden\" value=".$un." name=\"un\" />
                        <input type=\"hidden\" value=".$pw." name=\"pw\" />
                    ";
                }


				
				if($sessionRole=='admin'){
					echo "
						<li data-role=\"fieldcontain\">
							<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Role:</label>
							<select name=\"role\" data-mini=\"true\" data-inline=\"true\">
								<option ".$role1." value=\"admin\">Administrator</option>
								<option ".$role2." value=\"manager\">Office Manager</option>
								<option ".$role3." value=\"districtMa\">District Manager</option>
								<option ".$role4." value=\"insCollege\">Instructor's College</option>
								<option ".$role5." value=\"instructor\">Instructor</option>
								<option ".$role6." value=\"student\">Student</option>
							</select>
						</li>
					";
				}
				
				
				if($sessionRole=='districtMa'){
					if($id){
						if($role=='admin'){
							echo "
								<li data-role=\"fieldcontain\">
									<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Role:</label>
									<select name=\"role\" data-mini=\"true\" data-inline=\"true\">
										<option value=\"".$role."\">".$role."</option>
									</select>
								</li>
							"; 
						}else{
							echo "
								<li data-role=\"fieldcontain\">
									<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Role:</label>
									<select name=\"role\" data-mini=\"true\" data-inline=\"true\">
										<option ".$role3." value=\"districtMa\">District Manager</option>
										<option ".$role2." value=\"manager\">Office Manager</option>
										<option ".$role4." value=\"insCollege\">Instructor's College</option>
										<option ".$role5." value=\"instructor\">Instructor</option>
										<option ".$role6." value=\"student\">Student</option>
									</select>
								</li>
							";
						}
					}else{
						echo "
							<li data-role=\"fieldcontain\">
								<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Role:</label>
								<select name=\"role\" data-mini=\"true\" data-inline=\"true\">
									<option ".$role3." value=\"districtMa\">District Manager</option>
									<option ".$role2." value=\"manager\">Office Manager</option>
									<option ".$role4." value=\"insCollege\">Instructor's College</option>
									<option ".$role5." value=\"instructor\">Instructor</option>
									<option ".$role6." value=\"student\">Student</option>
								</select>
							</li>
						";
					}
				}

				if($sessionRole=='manager'){
					if($id){
						if($role=='admin' or $role=='districtMa' or $role=='insCollege' or $role=='manager'){
							echo "
								<li data-role=\"fieldcontain\">
									<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Role:</label>
									<select name=\"role\" data-mini=\"true\" data-inline=\"true\">
										<option value=\"".$role."\">".$role."</option>
									</select>
								</li>
							"; 
						}else{
							echo "
								<li data-role=\"fieldcontain\">
									<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Role:</label>
									<select name=\"role\" data-mini=\"true\" data-inline=\"true\">
										<option ".$role5." value=\"instructor\">Instructor</option>
										<option ".$role6." value=\"student\">Student</option>
									</select>
								</li>
							";
						}
					}else{
						echo "
							<li data-role=\"fieldcontain\">
								<label for=\"name\" style=\"display: block; float: left; width: 150px;\">Role:</label>
								<select name=\"role\" data-mini=\"true\" data-inline=\"true\">
									<option ".$role5." value=\"instructor\">Instructor</option>
									<option ".$role6." value=\"student\">Student</option>
								</select>
							</li>
						";
					}
				}
				
				
				
                echo "
					<li data-role=\"fieldcontain\">
						<label for=\"name\" style=\"display: block; float: left; width: 100px;\">Notes:</label>
						<textarea  name=\"notes\" type=\"textarea\" id=\"notes\" data-mini=\"true\" data-inline=\"true\">".$notes."</textarea>
					</li>
				";
			?>
					<li  data-role=\"fieldcontain\">
						<input type="submit" name="submit" value="<?php if($id){ echo "Update"; }else{ echo "Add"; } ?>" data-icon="<?php if($id){ echo "Edit"; }else{ echo "Add"; } ?>">
					</li>
				</ul>
				
				
					<?php
						if($id){
							echo "
								<input type=\"hidden\" value=".$id." name=\"id\" />
							";
						}
					?>

				
			</form>    	
			<p style="margin-bottom: 20px;">
				<a href="admin.php"  data-role="button" data-mini="true" data-inline="true" data-icon="plus" >Return to the admin tool</a>
					<?php
						if($id){
							if($sessionRole=="admin"){
								echo "
									<a href=\"update_processor.php?delete=".$id."\" data-role=\"button\" data-mini=\"true\" data-inline=\"true\" data-icon=\"delete\" >Delete (Cannot be undone)</a>
								";
							}
							if($sessionRole=="districtMa"){
								if($role!="admin" and $role!="districtMa"){
									echo "
										<a href=\"update_processor.php?delete=".$id."\" data-role=\"button\" data-mini=\"true\" data-inline=\"true\" data-icon=\"delete\" >Delete (Cannot be undone)</a>
									";
								}
							}
							if($sessionRole=="manager"){
								if($role != "admin" and $role != "districtMa" and $role != "manager"){
									echo "
										<a href=\"update_processor.php?delete=".$id."\" data-role=\"button\" data-mini=\"true\" data-inline=\"true\" data-icon=\"delete\" >Delete (Cannot be undone)</a>
									";
								}
							}
						}
					?>


				
			</p>
	</div>
  </div>
  <div id="columnbottom">&nbsp;</div>
</div>
<div id="footer">
  <div id="footercontent">
    <p class="footphone">(623) 581-2000 Glendale, AZ  • (801) 566-6364 Sandy, UT • (801) 967-2300 Taylorsville, UT<br />
    </p>
<p>&copy; Copyright 2010 Shaolin Arts, LLC. All Rights Reserved.</p>
  </div>
</div>


</body>
</html>


<?php ob_end_flush();?>
