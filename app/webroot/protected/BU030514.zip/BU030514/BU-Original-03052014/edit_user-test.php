<?php

	// require 'includes/check_session.php';

	$sessionRole = $_SESSION['sessionRole'];

	$sessionStudio = $_SESSION['sessionStudio'];

	require 'includes/roleCheck.php';

	require 'includes/connect.php';

?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Shaolin Arts</title>





<link href="p7curvitude/p7CRVboxes982_2col.css" rel="stylesheet" type="text/css" />

<link href="p7curvitude/p7CRV04.css" rel="stylesheet" type="text/css" />

<link href="p7pmm/p7PMMh13.css" rel="stylesheet" type="text/css" media="all" />



<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.css" />

	<link href="shaolinarts.min.css" rel="stylesheet" type="text/css" media="all" />



	<link rel="stylesheet" href="validation/css/validationEngine.jquery.css" type="text/css"/>

	<link rel="stylesheet" href="validation/css/template.css" type="text/css"/>

<script type="text/javascript" src="p7pmm/p7PMMscripts.js"></script>





	<script src="http://code.jquery.com/jquery-1.8.3.min.js"></script>

	<script src="http://code.jquery.com/mobile/1.3.1/jquery.mobile-1.3.1.js"></script>



<script>

		jQuery(document).ready(function(){

			// binds form submission and fields to the validation engine

			jQuery("#form1").validationEngine('attach');

		});

	</script>





<meta name="Keywords" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, Utah, Arizona, Marital Arts" />

<meta name="Description" content="Shaolin Arts is a family system of martial arts over 3,000 years old. Common western terms used to describe it would be Kung Fu, Tai Chi Chuan, Karate, Self Defense, Wushu, Animal Styles, Mixed Martial Arts, Chi Qi Gung or grappling. " />



<style type="text/css">



</style>









</head>

<body>

<div id="masthead" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, UtahArizonaMarital Arts">

  <div id="logo" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, UtahArizonaMarital Arts"><img src="images/logoanimbk.gif" alt="" width="982" height="160" /></div>

  <div id="navbar">

    <div id="navbar_inner">

      <div id="navbar_inner2">

<div id="p7PMM_1" class="p7PMMh13">

  <ul class="p7PMM">

    <li><a href="../index.html">Home</a></li>

    <li><a href="pages/class-information.html">Class Information</a></li>

    <li><a href="pages/locations.html">Locations</a></li>

    <li><a ajax="false" href="pages/faq.html" data-ajax="false">FAQ</a></li>

    <li><a href="pages/events.html">Current Events</a></li>

    <li><a href="pages/areas-of-study.html">Areas of Study</a>

      <div>

        <ul>

          <li><a href="pages/kung-fu.html">Kung Fu</a></li>

          <li><a href="pages/tai-chi.html">Tai Chi</a></li>

          <li><a href="pages/self-defense.html">Self Defense</a></li>

          <li><a href="pages/mma.html">Mixed Martial Arts</a></li>

          <li><a href="pages/fitness.html">Fitness</a></li>

        </ul>

      </div>

    </li>

    <li><a href="pages/information.html">More Information</a>

      <div>

        <ul>

          <li><a href="pages/about-us.html">About Shaolin Arts</a></li>

          <li><a href="pages/events.html">Current Events</a></li>

          <li><a href="pages/class-information.html">Class Information</a></li>

          <li><a href="pages/locations.html">Locations</a></li>

          <li><a ajax="false" href="pages/faq.html" data-ajax="false">FAQ</a></li>

          <li><a href="pages/contact.html">Contact Us</a></li>

          <li><a href="pages/history.html">History &amp; Philosophy</a></li>

        </ul>

      </div>

    </li>

     <li><a href="Logout.php">Log Out</a></li>

  </ul>

  <div class="p7pmmclearfloat">&nbsp;</div>

  <!--[if lte IE 6]>

<style>

.p7PMMh13 ul ul li {float:left; clear: both; width: 100%;}.p7PMMh13 {text-align: left;}.p7PMMh13, .p7PMMh13 ul ul a {zoom: 1;}

.p7PMMh13 ul ul {border: 1px solid #fff; background-color: #F90 !important;}

.p7PMMh13 ul ul a, .p7PMMh13 ul ul li {background-image: none !important;}

.p7PMMh13 ul ul a {padding: 6px 12px !important;}

.p7PMMh13 ul ul a:hover {background-color: #010101 !important;}

.p7PMMh13 ul ul a.trig_open {background-color: #000 !important; color: #fff;}

.p7PMMh13 ul ul a.trig_closed {background-image: url(p7pmm/img/pmm_east_dark.gif) !important; background-repeat: no-repeat; background-position: right center;}

</style>

<![endif]-->

  <!--[if IE 5]>

<style>.p7PMMh13, .p7PMMh13 ul ul a {height: 1%; overflow: visible !important;} .p7PMMh13 {width: 100%;}</style>

<![endif]-->

  <!--[if IE 7]>

<style>.p7PMMh13, .p7PMMh13 a{zoom:1;}.p7PMMh13 ul ul li{float:left;clear:both;width:100%;}</style>

<![endif]-->

  <script type="text/javascript">

<!--

P7_PMMop('p7PMM_1',1,1,-10,-20,0,0,0,1,0,3,1,1,0,0);

//-->

  </script>

</div>

<div class="clearfloat">&nbsp;</div>

      </div>

    </div>

  </div>

</div>

  <div class="c2_982" id="columnwrapper">

  <div id="columntop">&nbsp;</div>

  <div id="c1">

    <div class="content">

      <h2 class="topZero"><img src="images/Chuan-Fa-char-with-English.jpg" width="137" height="569" alt="chaun fa" /></h2>

      <p>&nbsp;</p>

      <p>&nbsp;</p>

      <p>&nbsp;</p>

      <p><img src="images/Chen-character-englishBlackGold.jpg" width="144" height="576" alt="chen tai chi chuan" /></p>

    </div>

  </div>

  <div id="c2">

    <div class="content">



<?php



if($id){

	$id=$array["id"];

	$role=$array["role"];

	$studioRole=$array["studioRole"];

	$picture=$array["picture"];

	$name=$array["name"];

	$lastName=$array["lastName"];

	$homePhone=$array["homePhone"];

	$cellPhone=$array["cellPhone"];

	$workPhone=$array["workPhone"];

	$email=$array["email"];

	$addres=$array["addres"];

	$city=$array["city"];

	$state=$array["state"];



	if($state=="AL"){$state1="selected";}

	if($state=="AK"){$state2="selected";}

	if($state=="AZ"){$state3="selected";}

	if($state=="AR"){$state4="selected";}

	if($state=="CA"){$state5="selected";}

	if($state=="CO"){$state6="selected";}

	if($state=="CT"){$state7="selected";}

	if($state=="DE"){$state8="selected";}

	if($state=="DC"){$state9="selected";}

	if($state=="FL"){$state0="selected";}

	if($state=="GA"){$state10="selected";}

	if($state=="HI"){$state11="selected";}

	if($state=="ID"){$state12="selected";}

	if($state=="IL"){$state13="selected";}

	if($state=="IN"){$state14="selected";}

	if($state=="IA"){$state15="selected";}

	if($state=="KS"){$state17="selected";}

	if($state=="KY"){$state18="selected";}

	if($state=="LA"){$state19="selected";}

	if($state=="ME"){$state20="selected";}

	if($state=="MD"){$state21="selected";}

	if($state=="MA"){$state22="selected";}

	if($state=="MI"){$state23="selected";}

	if($state=="MN"){$state24="selected";}

	if($state=="MS"){$state25="selected";}

	if($state=="MO"){$state26="selected";}

	if($state=="MT"){$state27="selected";}

	if($state=="NE"){$state28="selected";}

	if($state=="NV"){$state29="selected";}

	if($state=="NH"){$state30="selected";}

	if($state=="NJ"){$state31="selected";}

	if($state=="NM"){$state32="selected";}

	if($state=="NY"){$state33="selected";}

	if($state=="NC"){$state34="selected";}

	if($state=="ND"){$state35="selected";}

	if($state=="OH"){$state36="selected";}

	if($state=="OK"){$state37="selected";}

	if($state=="OR"){$state38="selected";}

	if($state=="PA"){$state39="selected";}

	if($state=="RI"){$state40="selected";}

	if($state=="SC"){$state41="selected";}

	if($state=="SD"){$state42="selected";}

	if($state=="TN"){$state43="selected";}

	if($state=="TX"){$state44="selected";}

	if($state=="UT"){$state45="selected";}

	if($state=="VT"){$state46="selected";}

	if($state=="VA"){$state47="selected";}

	if($state=="WA"){$state48="selected";}

	if($state=="WV"){$state49="selected";}

	if($state=="WI"){$state40="selected";}

	if($state=="WY"){$state51="selected";}



	$zip=$array["zip"];

	$birthday=$array["birthday"];

	$spouseGuardian=$array["spouseGuardian"];

	$sgPhone=$array["sgPhone"];

	$sgCellPhone=$array["sgCellPhone"];

	$startDate=$array["startDate"];

	$dueDate=$array["dueDate"];



	$studio=$array["studio"];

	if($studio==1){$studio1="selected";}

	if($studio==2){$studio2="selected";}

	if($studio==3){$studio3="selected";}

	if($studio==4){$studio4="selected";}



	$taiChiStudio=$array["taiChiStudio"];

	if($taiChiStudio==1){$taiChiStudio1="selected";}

	if($taiChiStudio==2){$taiChiStudio2="selected";}

	if($taiChiStudio==3){$taiChiStudio3="selected";}

	if($taiChiStudio==4){$taiChiStudio4="selected";}



	$studioRole=$array["studioRole"];

	if($studioRole==1){$studioRole1="selected";}

	if($studioRole==2){$studioRole2="selected";}

	if($studioRole==3){$studioRole3="selected";}

	if($studioRole==4){$studioRole4="selected";}



	$program=$array["program"];

	if($program==1){$program1="selected";}

	if($program==2){$program2="selected";}

	if($program==3){$program3="selected";}



	$longTermProgram=$array["longTermProgram"];

	if($longTermProgram==1){$longTermProgram1="selected";}

	if($longTermProgram==2){$longTermProgram2="selected";}

	if($longTermProgram==3){$longTermProgram3="selected";}

	if($longTermProgram==4){$longTermProgram4="selected";}

	if($longTermProgram==5){$longTermProgram5="selected";}

	if($longTermProgram==6){$longTermProgram6="selected";}



	$TaiChiProgram=$array["TaiChiProgram"];

	if($TaiChiProgram==1){$TaiChiProgram1="selected";}

	if($TaiChiProgram==2){$TaiChiProgram2="selected";}

	if($TaiChiProgram==3){$TaiChiProgram3="selected";}

	if($TaiChiProgram==4){$TaiChiProgram4="selected";}

	if($TaiChiProgram==5){$TaiChiProgram5="selected";}

	if($TaiChiProgram==6){$TaiChiProgram6="selected";}



	$lessonType=$array["lessonType"];

	if($lessonType==1){$lessonType1="selected";}

	if($lessonType==2){$lessonType2="selected";}

	if($lessonType==3){$lessonType3="selected";}

	if($lessonType==4){$lessonType4="selected";}



	$TaiChiLessonType=$array["TaiChiLessonType"];

	if($TaiChiLessonType==1){$TaiChiLessonType1="selected";}

	if($TaiChiLessonType==2){$TaiChiLessonType2="selected";}

	if($TaiChiLessonType==3){$TaiChiLessonType3="selected";}

	if($TaiChiLessonType==4){$TaiChiLessonType4="selected";}



	$rank=$array["rank"];

	if($rank==1){$rank1="selected";}

	if($rank==2){$rank2="selected";}

	if($rank==3){$rank3="selected";}

	if($rank==4){$rank4="selected";}

	if($rank==5){$rank5="selected";}

	if($rank==6){$rank6="selected";}

	if($rank==7){$rank7="selected";}

	if($rank==8){$rank8="selected";}

	if($rank==9){$rank9="selected";}

	if($rank==10){$rank10="selected";}

	if($rank==11){$rank11="selected";}

	if($rank==12){$rank12="selected";}

	if($rank==13){$rank13="selected";}

	if($rank==14){$rank14="selected";}

	if($rank==15){$rank15="selected";}

	if($rank==16){$rank16="selected";}

	if($rank==17){$rank17="selected";}

	if($rank==18){$rank18="selected";}

	if($rank==19){$rank19="selected";}

	if($rank==20){$rank20="selected";}

	if($rank==21){$rank21="selected";}

	if($rank==22){$rank22="selected";}

	if($rank==23){$rank23="selected";}

	if($rank==24){$rank24="selected";}

	if($rank==25){$rank25="selected";}

	if($rank==26){$rank26="selected";}

	if($rank==27){$rank27="selected";}

	if($rank==28){$rank28="selected";}

	if($rank==29){$rank29="selected";}

	if($rank==30){$rank30="selected";}

	if($rank==31){$rank31="selected";}

	if($rank==32){$rank32="selected";}

	if($rank==33){$rank33="selected";}

	if($rank==34){$rank34="selected";}



	$TaiChiRank=$array["TaiChiRank"];

	if($TaiChiRank==0){$TaiChiRank1="selected";}

	if($TaiChiRank==1){$TaiChiRank1="selected";}

	if($TaiChiRank==2){$TaiChiRank2="selected";}

	if($TaiChiRank==3){$TaiChiRank3="selected";}

	if($TaiChiRank==4){$TaiChiRank4="selected";}

	if($TaiChiRank==5){$TaiChiRank5="selected";}

	if($TaiChiRank==6){$TaiChiRank6="selected";}

	if($TaiChiRank==7){$TaiChiRank7="selected";}

	if($TaiChiRank==8){$TaiChiRank8="selected";}



	$rankDate=$array["rankDate"];

	$status=$array["status"];

	if($status==0){$status1="selected";}

	if($status==1){$status2="selected";}

	if($status==2){$status3="selected";}



	$TaiChiRankDate=$array["TaiChiRankDate"];

	$taiChiStatus=$array["taiChiStatus"];

	if($taiChiStatus==0){$taiChiStatus1="selected";}

	if($taiChiStatus==1){$taiChiStatus2="selected";}

	if($taiChiStatus==2){$taiChiStatus3="selected";}



	$studentID=$array["studentID"];

	$ice1=$array["ice1"];

	$ice1Phone=$array["ice1Phone"];

	$ice1CellPhone=$array["ice1CellPhone"];

	$ice2=$array["ice2"];

	$ice2Phone=$array["ice2Phone"];

	$ice2CellPhone=$array["ice2CellPhone"];

	$ice3=$array["ice3"];

	$ice3Phone=$array["ice3Phone"];

	$ice3CellPhone=$array["ice3CellPhone"];

	$un=$array["un"];

	$pw=$array["pw"];





	if($role=='student'){$role6="selected";}

	if($role=='instructor'){$role5="selected";}

	if($role=='insCollege'){$role4="selected";}

	if($role=='manager'){$role3="selected";}

	if($role=='districtMa'){$role2="selected";}

	if($role=='admin'){$role1="selected";}



	$notes=$array["notes"];

}

?>



<h1>

	<?php

		if($id){

			echo "Edit User";

		}else{

			echo "Add User";

		}

	?>

</h1>

<p style="margin-bottom: 20px;"><a href="admin.php"  data-role="button" data-mini="true" data-inline="true" data-icon="back" >Return to the admin tool</a></p>



	<form name="form1" id="form1" method="post" data-ajax="false" action="update_processor.php">

		<ul data-role="listview" data-inset="true">

			<?php if($sessionRole=='admin'){ ?>

			<li data-role="fieldcontain">

				<span><?php echo $sessionRole; ?></span>

			</li>

			<?php } ?>

			<li data-role="fieldcontain">

				<h1><?php echo"$name $lastName"; ?></h1>

			</li>

			<li>

				<input type="submit" name="submit" value="Update">

			</li>

		</ul>



		<div data-role="collapsible-set" data-theme="a" data-content-theme="a">

			<div data-role="collapsible">

				<h3>Student</h3>

				<ul data-role="listview" data-inset="true">

					<?php if($picture){?>

					<li data-role="fieldcontain" style="text-align: center; padding: 30px;">

						<span><img src="upload<?php echo $picture; ?>" style="width: 300px;" /></span>

					</li>

					<?php } ?>

					<?php if($id){?>

					<li data-role="fieldcontain">

						<a href="image_upload.php?id=<?php echo $id; ?>">Update Image</a>

					</li>

					<?php } ?>

					<li data-role="fieldcontain">

						<label for="name" style="display: block;">First Name:</label>

						<input name="name" type="text" class="validate[required,custom[onlyLetterNumber]] text-input" id="name" data-mini="true" data-inline="true" value="<?php echo $name; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="lastName" style="display: block;">Last Name:</label>

						<input name="lastName" type="text" class="validate[required,custom[onlyLetterNumber]] text-input" id="lastName" data-mini="true" data-inline="true" value="<?php echo $lastName; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="birthday" style="display: block;">Birth Day:</label>

						<input name="birthday" type="date"  id="birthday" data-mini="true" data-inline="true" value="<?php echo $birthday; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="homePhone" style="display: block;">Home Phone:</label>

						<input name="homePhone" type="text" id="homePhone" data-mini="true" data-inline="true" value="<?php echo $homePhone; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="workPhone" style="display: block;">Work Phone:</label>

						<input name="workPhone" type="text" id="workPhone" data-mini="true" data-inline="true" value="<?php echo $workPhone; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="email" style="display: block;">Email:</label>

						<input name="email" type="text" class="validate[required,custom[email]] text-input" id="email" data-mini="true" data-inline="true" value="<?php echo $email; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="addres" style="display: block;">Address:</label>

						<input name="addres" type="text" class="validate[required,custom[onlyLetterNumber]] text-input" id="addres" data-mini="true" data-inline="true" value="<?php echo $addres; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="city" style="display: block;">City:</label>

						<input name="city" type="text" class="validate[required,custom[onlyLetterNumber]] text-input" id="city" data-mini="true" data-inline="true" value="<?php echo $city; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="name" style="display: block;">State:</label>

						<select name="state" id="state" data-mini="true" data-inline="true" name="State">

							<option <?php echo $state1; ?> value="AL">Alabama</option>

							<option <?php echo $state2; ?> value="AK">Alaska</option>

							<option <?php echo $state3; ?> value="AZ">Arizona</option>

							<option <?php echo $state4; ?> value="AR">Arkansas</option>

							<option <?php echo $state5; ?> value="CA">California</option>

							<option <?php echo $state6; ?> value="CO">Colorado</option>

							<option <?php echo $state7; ?> value="CT">Connecticut</option>

							<option <?php echo $state8; ?> value="DE">Delaware</option>

							<option <?php echo $state9; ?> value="DC">District Of Columbia</option>

							<option <?php echo $state10; ?> value="FL">Florida</option>

							<option <?php echo $state11; ?> value="GA">Georgia</option>

							<option <?php echo $state12; ?> value="HI">Hawaii</option>

							<option <?php echo $state13; ?> value="ID">Idaho</option>

							<option <?php echo $state14; ?> value="IL">Illinois</option>

							<option <?php echo $state15; ?> value="IN">Indiana</option>

							<option <?php echo $state16; ?> value="IA">Iowa</option>

							<option <?php echo $state17; ?> value="KS">Kansas</option>

							<option <?php echo $state18; ?> value="KY">Kentucky</option>

							<option <?php echo $state19; ?> value="LA">Louisiana</option>

							<option <?php echo $state20; ?> value="ME">Maine</option>

							<option <?php echo $state21; ?> value="MD">Maryland</option>

							<option <?php echo $state22; ?> value="MA">Massachusetts</option>

							<option <?php echo $state23; ?> value="MI">Michigan</option>

							<option <?php echo $state24; ?> value="MN">Minnesota</option>

							<option <?php echo $state25; ?> value="MS">Mississippi</option>

							<option <?php echo $state26; ?> value="MO">Missouri</option>

							<option <?php echo $state27; ?> value="MT">Montana</option>

							<option <?php echo $state28; ?> value="NE">Nebraska</option>

							<option <?php echo $state29; ?> value="NV">Nevada</option>

							<option <?php echo $state30; ?> value="NH">New Hampshire</option>

							<option <?php echo $state31; ?> value="NJ">New Jersey</option>

							<option <?php echo $state32; ?> value="NM">New Mexico</option>

							<option <?php echo $state33; ?> value="NY">New York</option>

							<option <?php echo $state34; ?> value="NC">North Carolina</option>

							<option <?php echo $state35; ?> value="ND">North Dakota</option>

							<option <?php echo $state36; ?> value="OH">Ohio</option>

							<option <?php echo $state37; ?> value="OK">Oklahoma</option>

							<option <?php echo $state38; ?> value="OR">Oregon</option>

							<option <?php echo $state39; ?> value="PA">Pennsylvania</option>

							<option <?php echo $state40; ?> value="RI">Rhode Island</option>

							<option <?php echo $state41; ?> value="SC">South Carolina</option>

							<option <?php echo $state42; ?> value="SD">South Dakota</option>

							<option <?php echo $state43; ?> value="TN">Tennessee</option>

							<option <?php echo $state44; ?> value="TX">Texas</option>

							<option <?php echo $state45; ?> value="UT">Utah</option>

							<option <?php echo $state46; ?> value="VT">Vermont</option>

							<option <?php echo $state47; ?> value="VA">Virginia</option>

							<option <?php echo $state48; ?> value="WA">Washington</option>

							<option <?php echo $state49; ?> value="WV">West Virginia</option>

							<option <?php echo $state50; ?> value="WI">Wisconsin</option>

							<option <?php echo $state51; ?> value="WY">Wyoming</option>

						</select>

					</li>

					<li data-role="fieldcontain">

						<label for="zip" style="display: block;">Zip:</label>

						<input name="zip" type="text" class="validate[required,custom[Number]] text-input" id="zip" data-mini="true" data-inline="true" value="<?php echo $zip; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="studentID" style="display: block;">Student ID:</label>

						<input name="studentID" type="text" id="studentID" data-mini="true" data-inline="true" value="<?php echo $studentID; ?>"/>

					</li>

				</ul>

			</div>



			<div data-role="collapsible">

				<h3>ICE Info</h3>

				<ul data-role="listview" data-inset="true">

					<li data-role="fieldcontain">

						<label for="spouseGuardian" style="display: block;">Spouse / Guardian:</label>

						<input name="spouseGuardian" type="text" id="spouseGuardian" data-mini="true" data-inline="true" value="<?php echo $spouseGuardian; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="sgPhone" style="display: block;">Phone:</label>

						<input name="sgPhone" type="text" id="sgPhone" data-mini="true" data-inline="true" value="<?php echo $sgPhone; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="sgCellPhone" style="display: block;">Cell Phone:</label>

						<input name="sgCellPhone" type="text" id="sgCellPhone" data-mini="true" data-inline="true" value="<?php echo $sgCellPhone; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="ice1" style="display: block;">1. ICE Name:</label>

						<input name="ice1" type="text" id="ice1" data-mini="true" data-inline="true" value="<?php echo $ice1; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="ice1Phone" style="display: block;">1. Phone:</label>

						<input name="ice1Phone" type="text" id="ice1Phone" data-mini="true" data-inline="true" value="<?php echo $ice1Phone; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="ice1CellPhone" style="display: block;">1. Cell Phone:</label>

						<input name="ice1CellPhone" type="text" id="ice1CellPhone" data-mini="true" data-inline="true" value="<?php echo $ice1CellPhone; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="ice2" style="display: block;">2. ICE Name::</label>

						<input name="ice2" type="text" id="ice2" data-mini="true" data-inline="true" value="<?php echo $ice2; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="ice2Phone" style="display: block;">2. Phone:</label>

						<input name="ice2Phone" type="text" id="ice2Phone" data-mini="true" data-inline="true" value="<?php echo $ice2Phone; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="ice2CellPhone" style="display: block;">2. Cell Phone:</label>

						<input name="ice2CellPhone" type="text" id="ice2CellPhone" data-mini="true" data-inline="true" value="<?php echo $ice2CellPhone; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="ice3" style="display: block;">3. ICE Name::</label>

						<input name="ice3" type="text" id="ice3" data-mini="true" data-inline="true" value="<?php echo $ice3; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="ice3Phone" style="display: block;">3. Phone:</label>

						<input name="ice3Phone" type="text" id="ice3Phone" data-mini="true" data-inline="true" value="<?php echo $ice3Phone; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="ice3CellPhone" style="display: block;">3. Cell Phone:</label>

						<input name="ice3CellPhone" type="text" id="ice3CellPhone" data-mini="true" data-inline="true" value="<?php echo $ice3CellPhone; ?>"/>

					</li>

				</ul>

			</div>

			<div data-role="collapsible">

				<h3>Program</h3>

				<ul data-role="listview" data-inset="true">

					<li data-role="fieldcontain">

						<label for="name" style="display: block;">Program:</label>

						<select name="program" data-mini="true" data-inline="true">

							<option <?php echo $program1; ?> value="1">Tai Chi</option>

							<option <?php echo $program2; ?> value="2">Kung Fu</option>

							<option <?php echo $program3; ?> value="3">Kung Fu and Tai Chi</option>

						</select>

					</li>

				</ul>

			</div>

			<div data-role="collapsible">

				<h3>Kung Fu</h3>

				<ul data-role="listview" data-inset="true">

					<li data-role="fieldcontain">

						<label for="name" style="display: block;">Kung Fu Studio:</label>

						<select name="studio" data-mini="true" data-inline="true" >

						<?php if($sessionRole=='manager'){ ?>

							<option value="<?php echo $studio; ?>">

								<?php

									if($studio==1){echo "Glendale, AZ";}

									if($studio==2){echo "Sandy, UT";}

									if($studio==3){echo "Taylorsville, UT";}

									if($studio==4){echo "Sandy and Taylorsville,UT";}

								?>

							</option>

						<?php }else{ ?>

							<option <?php echo $studio1; ?> value="1">Glendale, AZ</option>

							<option <?php echo $studio2; ?> value="2">Sandy, UT</option>

							<option <?php echo $studio3; ?> value="3">Taylorsville, UT</option>

							<option <?php echo $studio4; ?> value="4">Sandy and Taylorsville,UT</option>

						<?php } ?>

						</select>



					</li>

					<li data-role="fieldcontain">

						<label for="status" style="display: block;">Kung Fu Status:</label>

						<select name="status" data-mini="true" data-inline="true">

							<?php if($id){?>

								<option <?php echo $status1; ?> value="0">Active</option>

								<option <?php echo $status2; ?> value="1">Not Active</option>

								<option <?php echo $status3; ?> value="2">Non Student</option>

							<?php }else{?>

								<option value="0">Active</option>

								<option value="1">Not Active</option>

								<option selected value="2">Non Student</option>

							<?php }?>

						</select>

					</li>

					<li data-role="fieldcontain">

						<label for="longTermProgram" style="display: block;">Kung Fu Terms:</label>

						<select name="longTermProgram" data-mini="true" data-inline="true">

							  <option <?php echo $longTermProgram1; ?> value="1">BPS</option>

							  <option <?php echo $longTermProgram2; ?> value="2">contract</option>

							  <option <?php echo $longTermProgram3; ?> value="3">3 Months</option>

							  <option <?php echo $longTermProgram4; ?> value="4">6 Months</option>

							  <option <?php echo $longTermProgram5; ?> value="5">12 Months</option>

							  <option <?php echo $longTermProgram6; ?> value="6">Month to Month</option>

						</select>

					</li>

					<li data-role="fieldcontain">

						<label for="lessonType" style="display: block;">Kung Fu Lesson Type:</label>

						<select name="lessonType" data-mini="true" data-inline="true">

							<option <?php echo $lessonType1; ?> value="1">Group</option>

							<option <?php echo $lessonType2; ?> value="2">Private</option>

							<option <?php echo $lessonType3; ?> value="3">Accelerated</option>

							<option <?php echo $lessonType4; ?> value="4">BSP</option>

						</select>

					</li>

					<li data-role="fieldcontain">

						<label for="rank" style="display: block;">Kung Fu Rank:</label>

						<?php

							if($sessionRole=="admin" or $sessionRole=="districtMa"){

						?>

						<select name="rank" data-mini="true" data-inline="true">

							<option <?php echo $rank23; ?> value="23">Youth White</option>

							<option <?php echo $rank24; ?> value="24">Youth Yellow</option>

							<option <?php echo $rank25; ?> value="25">Youth Orange</option>

							<option <?php echo $rank26; ?> value="26">Youth Purple</option>

							<option <?php echo $rank27; ?> value="27">Youth Blue</option>

							<option <?php echo $rank27; ?> value="28">Youth Blue Advanced</option>

							<option <?php echo $rank29; ?> value="29">Youth Green</option>

							<option <?php echo $rank30; ?> value="30">Youth Green Advanced</option>

							<option <?php echo $rank31; ?> value="31">Youth Red</option>

							<option <?php echo $rank32; ?> value="32">Youth Brown</option>

							<option <?php echo $rank33; ?> value="33">Youth Brown Advanced</option>

							<option <?php echo $rank1; ?> value="1">White</option>

							<option <?php echo $rank2; ?> value="2">Yellow</option>

							<option <?php echo $rank3; ?> value="3">Orange</option>

							<option <?php echo $rank4; ?> value="4">Purple</option>

							<option <?php echo $rank5; ?> value="5">Blue</option>

							<option <?php echo $rank6; ?> value="6">Blue Advanced</option>

							<option <?php echo $rank7; ?> value="7">Green</option>

							<option <?php echo $rank8; ?> value="8">Green Advanced</option>

							<option <?php echo $rank9; ?> value="9">Red</option>

							<option <?php echo $rank10; ?> value="10">Brown</option>

							<option <?php echo $rank11; ?> value="11">Brown Advanced</option>

							<option <?php echo $rank12; ?> value="12">Sidi</option>

							<option <?php echo $rank13; ?> value="13">Sidi Dai Lou</option>

							<option <?php echo $rank14; ?> value="14">Si Hing</option>

							<option <?php echo $rank15; ?> value="15">Si Hing Dai Lou</option>

							<option <?php echo $rank16; ?> value="16">Sisuk</option>

							<option <?php echo $rank17; ?> value="17">Sisuk Dai Lou</option>

							<option <?php echo $rank18; ?> value="18">Sifu</option>

							<option <?php echo $rank19; ?> value="19">Si Bok</option>

							<option <?php echo $rank20; ?> value="20">Si Gung</option>

							<option <?php echo $rank21; ?> value="21">Si Tai Gung</option>

							<option <?php echo $rank22; ?> value="22">Si Jo</option>

						</select>



						<?php

							}else{

								if($id){

						?>



						<select name="rank" data-mini="true" data-inline="true">

							<option <?php echo $rank; ?> value="<?php echo $rank; ?>">

								<?php

									if($rank==23){echo "Youth White";};

									if($rank==24){echo "Youth Yellow";};

									if($rank==25){echo "Youth Orange";};

									if($rank==26){echo "Youth Purple";};

									if($rank==27){echo "Youth Blue";};

									if($rank==28){echo "Youth Blue Advanced";};

									if($rank==29){echo "Youth Green";};

									if($rank==30){echo "Youth Green Advanced";};

									if($rank==31){echo "Youth Red";};

									if($rank==32){echo "Youth Brown";};

									if($rank==33){echo "Youth Brown Advanced";};

									if($rank==1){echo "White";};

									if($rank==2){echo "Yellow";};

									if($rank==3){echo "Orange";};

									if($rank==4){echo "Purple";};

									if($rank==5){echo "Blue";};

									if($rank==6){echo "Blue Advanced";};

									if($rank==7){echo "Green";};

									if($rank==8){echo "Green Advanced";};

									if($rank==9){echo "Red";};

									if($rank==10){echo "Brown";};

									if($rank==11){echo "Brown Advanced";};

									if($rank==12){echo "Sidi";};

									if($rank==13){echo "Sidi Dai Lou";};

									if($rank==14){echo "Si Hing";};

									if($rank==15){echo "Si Hing Dai Lou";};

									if($rank==16){echo "Sisuk";};

									if($rank==17){echo "Sisuk Dai Lou";};

									if($rank==18){echo "Sifu";};

									if($rank==19){echo "Si Bok";};

									if($rank==20){echo "Si Gung";};

									if($rank==21){echo "Si Tai Gung";};

									if($rank==22){echo "Si Jo";};

								?>

							</option>

						</select>



						<?php

								}else{

						?>

						<select name="rank" data-mini="true" data-inline="true">

							<option <?php echo $rank23; ?> value="23">Youth White</option>

							<option <?php echo $rank1; ?> value="1">White</option>

						</select>

						<?php

							}

						}

						?>

					</li>

					<li data-role="fieldcontain">

						<label for="rankDate" style="display: block;">Kung Fu Rank Date:</label>

						<input name="rankDate" type="date" id="rankDate" data-mini="true" data-inline="true" value="<?php echo $rankDate; ?>"/>

					</li>

				</ul>

			</div>

			<div data-role="collapsible">

				<h3>Tai Chi</h3>

				<ul data-role="listview" data-inset="true">

					<li data-role="fieldcontain">

						<label for="name" style="display: block;">Tai Chi Studio:</label>

						<select name="taiChiStudio" data-mini="true" data-inline="true" >

						<?php if($sessionRole=='manager'){ ?>

							<option value="<?php echo $taiChiStudio; ?>">

								<?php

									if($taiChiStudio==1){echo "Glendale, AZ";}

									if($taiChiStudio==2){echo "Sandy, UT";}

									if($taiChiStudio==3){echo "Sandy, UT";}

									if($taiChiStudio==4){echo "Sandy and Taylorsville,UT";}

								?>

							</option>

						<?php }else{ ?>

							<option <?php echo $taiChiStudio1; ?> value="1">Glendale, AZ</option>

							<option <?php echo $taiChiStudio2; ?> value="2">Sandy, UT</option>

							<option <?php echo $taiChiStudio3; ?> value="3">Taylorsville, UT</option>

							<option <?php echo $taiChiStudio4; ?> value="4">Sandy and Taylorsville,UT</option>

						<?php } ?>

						</select>



					</li>

					<li data-role="fieldcontain">

						<label for="taiChiStatus" style="display: block;">Tai Chi Status:</label>

						<select name="taiChiStatus" data-mini="taiChiStatus" data-inline="true">

							<?php if($id){?>

								<option <?php echo $taiChiStatus1; ?> value="0">Active</option>

								<option <?php echo $taiChiStatus2; ?> value="1">Not Active</option>

								<option <?php echo $taiChiStatus3; ?> value="2">Non Student</option>

							<?php }else{?>

								<option value="0">Active</option>

								<option value="1">Not Active</option>

								<option selected value="2">Non Student</option>

							<?php }?>





							</select>

					</li>

					<li data-role="fieldcontain">

						<label for="TaiChiProgram" style="display: block;">Tai Chi Terms:</label>

						<select name="TaiChiProgram" data-mini="true" data-inline="true">

							  <option <?php echo $TaiChiProgram1; ?> value="1">BPS</option>

							  <option <?php echo $TaiChiProgram2; ?> value="2">contract</option>

							  <option <?php echo $TaiChiProgram3; ?> value="3">3 Months</option>

							  <option <?php echo $TaiChiProgram4; ?> value="4">6 Months</option>

							  <option <?php echo $TaiChiProgram5; ?> value="5">12 Months</option>

							  <option <?php echo $TaiChiProgram6; ?> value="6">Month to Month</option>

						</select>

					</li>

					<li data-role="fieldcontain">

						<label for="TaiChiLessonType" style="display: block;">Tai Chi Lesson Type:</label>

						<select name="TaiChiLessonType" data-mini="true" data-inline="true">

							<option <?php echo $TaiChiLessonType1; ?> value="1">Group</option>

							<option <?php echo $TaiChiLessonType2; ?> value="2">Private</option>

							<option <?php echo $TaiChiLessonType3; ?> value="3">Accelerated</option>

							<option <?php echo $TaiChiLessonType4; ?> value="4">BSP</option>

						</select>

					</li>

					<li data-role="fieldcontain">

						<label for="TaiChiRank" style="display: block;">Tai Chi Rank:</label>

						<select name="TaiChiRank" data-mini="true" data-inline="true">

						<?php if($sessionRole=='admin' or $sessionRole=='districtMa'){ ?>

							<option <?php echo $TaiChiRank1; ?> value="0">White Sash</option>

							<option <?php echo $TaiChiRank5; ?> value="5">Youth Gold Sash</option>

							<option <?php echo $TaiChiRank6; ?> value="6">Youth Blue Sash</option>

							<option <?php echo $TaiChiRank7; ?> value="7">Youth Red Sash</option>

							<option <?php echo $TaiChiRank1; ?> value="1">Gold Sash</option>

							<option <?php echo $TaiChiRank2; ?> value="2">Blue Sash</option>

							<option <?php echo $TaiChiRank3; ?> value="3">Red Sash</option>

							<option <?php echo $TaiChiRank4; ?> value="12">Sidi</option>

							<option <?php echo $TaiChiRank5; ?> value="13">Sidi Dai Lou</option>

							<option <?php echo $TaiChiRank6; ?> value="14">Si Hing</option>

							<option <?php echo $TaiChiRank7; ?> value="15">Si Hing Dai Lou</option>

							<option <?php echo $TaiChiRank8; ?> value="16">Sisuk</option>

							<option <?php echo $TaiChiRank9; ?> value="17">Sisuk Dai Lou</option>

							<option <?php echo $TaiChiRank10; ?> value="18">Sifu</option>

							<option <?php echo $TaiChiRank11; ?> value="19">Si Bok</option>

							<option <?php echo $TaiChiRank12; ?> value="20">Si Gung</option>

							<option <?php echo $TaiChiRank13; ?> value="21">Si Tai Gung</option>

							<option <?php echo $TaiChiRank14; ?> value="22">Si Jo</option>

						<?php }else{  if($id){ ?>

							<option <?php echo $TaiChiRank; ?> value="<?php echo $TaiChiRank; ?>">

								<?php

									if($TaiChiRank==0){echo "White Sash";};

									if($TaiChiRank==23){echo "Youth White";};

									if($TaiChiRank==5){echo "Youth Gold Sash";};

									if($TaiChiRank==6){echo "Youth Blue Sash";};

									if($TaiChiRank==7){echo "Youth Red Sash";};

									if($TaiChiRank==1){echo "Gold Sash";};

									if($TaiChiRank==2){echo "Blue Sash";};

									if($TaiChiRank==3){echo "Red Sash";};

									if($TaiChiRank==12){echo "Sidi";};

									if($TaiChiRank==13){echo "Sidi Dai Lou";};

									if($TaiChiRank==14){echo "Si Hing";};

									if($TaiChiRank==15){echo "Si Hing Dai Lou";};

									if($TaiChiRank==16){echo "Sisuk";};

									if($TaiChiRank==17){echo "Sisuk Dai Lou";};

									if($TaiChiRank==18){echo "Sifu";};

									if($TaiChiRank==19){echo "Si Bok";};

									if($TaiChiRank==20){echo "Si Gung";};

									if($TaiChiRank==21){echo "Si Tai Gung";};

									if($TaiChiRank==22){echo "Si Jo";};

									?>

						<?php 	} ?>

							<option <?php echo $TaiChiRank5; ?> value="5">Youth Gold Sash</option>

							<option <?php echo $TaiChiRank1; ?> value="1">Gold Sash</option>

						<?php } ?>



						</select>

					</li>

					<li data-role="fieldcontain">

						<label for="TaiChiRankDate" style="display: block;">Tai Chi Rank Date:</label>

						<input name="TaiChiRankDate" id="TaiChiRankDate" type="date" data-mini="true" data-inline="true" value="<?php echo $TaiChiRankDate; ?>"/>

					</li>

				</ul>

			</div>



			<?php

				if($sessionRole=="admin" or $sessionRole=="districtMa"){

			?>

			<div data-role="collapsible">

				<h3>Admin</h3>

				<ul data-role="listview" data-inset="true">

					<li data-role="fieldcontain">

						<label for="role" style="display: block;">Role:</label>

						<select name="role" data-mini="true" data-inline="true">

						<?php if($sessionRole=='admin' or $sessionRole=='districtMa'){ ?>

							<option <?php echo $role6; ?> value="student">Student</option>

							<option <?php echo $role5; ?> value="instructor">Instructor</option>

							<option <?php echo $role4; ?> value="insCollege">Instructors College</option>

							<option <?php echo $role3; ?> value="manager">Office Manager</option>

						<?php } ?>



						<?php if($sessionRole=='admin'){ ?>

							<option <?php echo $role2; ?> value="districtMa">Distric Manager</option>

							<option <?php echo $role1; ?> value="admin">Admin</option>

						<?php } ?>



						</select>

					</li>



					<li data-role="fieldcontain">

						<label for="name" style="display: block;">Studio Role:</label>

						<select name="studioRole" data-mini="true" data-inline="true" >

						<?php if($sessionRole=='manager'){ ?>

							<option value="<?php echo $studioRole; ?>">

								<?php

									if($studioRole==0){echo "None";}

									if($studioRole==1){echo "Glendale, AZ";}

									if($studioRole==2){echo "Sandy, UT";}

									if($studioRole==3){echo "Taylorsville, UT";}

									if($studioRole==4){echo "Sandy and Taylorsville,UT";}

								?>

							</option>

						<?php }else{ ?>

							<option <?php echo $studioRole1; ?> value="0">None</option>

							<option <?php echo $studioRole1; ?> value="1">Glendale, AZ</option>

							<option <?php echo $studioRole2; ?> value="2">Sandy, UT</option>

							<option <?php echo $studioRole3; ?> value="3">Taylorsville, UT</option>

							<option <?php echo $studioRole4; ?> value="4">Sandy and Taylorsville,UT</option>

						<?php } ?>

						</select>

					</li>



					<?php if($sessionRole=="admin"){ ?>

					<li data-role="fieldcontain">

						<label for="un" style="display: block;">User Name:</label>

						<input name="un" type="text" id="un" data-mini="true" data-inline="true" value="<?php echo $un; ?>"/>

					</li>

					<li data-role="fieldcontain">

						<label for="pw" style="display: block;">Password:</label>

						<input name="pw" type="text" id="pw" data-mini="true" data-inline="true" value="<?php echo $pw; ?>"/>

					</li>

				<?php } ?>

				</ul>

			</div>

			<?php } ?>



		</div>

		<ul data-role="listview" data-inset="true">

			<li data-role="fieldcontain">

				<label for="name" style="display: block;">Notes:</label>

				<input name="notes" type="text" id="name" data-mini="true" data-inline="true" value="<?php echo $notes; ?>"/>

			</li>

		</ul>

		<ul data-role="listview" data-inset="true">

			<li >

				<input type="submit" name="submit" value="<?php if($id){ echo "Update"; }else{ echo "Add"; } ?>" data-icon="<?php if($id){ echo "Edit"; }else{ echo "Add"; } ?>">

			</li>

		</ul>

		<input type="hidden" value="<?php echo $id; ?>" name="id" />





			</form>





			<p style="margin-bottom: 20px;">

				<a href="admin.php"  data-role="button" data-mini="true" data-inline="true" data-icon="plus" >Return to the admin tool</a>

					<?php

						if($id){

							if($sessionRole=="admin"){

								echo "

									<a href=\"update_processor.php?delete=".$id."\" data-role=\"button\" data-mini=\"true\" data-inline=\"true\" data-icon=\"delete\" >Delete (Cannot be undone)</a>

								";

							}

							if($sessionRole=="districtMa"){

								if($sessionRole!="admin" and $sessionRole!="districtMa"){

									echo "

										<a href=\"update_processor.php?delete=".$id."\" data-role=\"button\" data-mini=\"true\" data-inline=\"true\" data-icon=\"delete\" >Delete (Cannot be undone)</a>

									";

								}

							}

							if($sessionRole=="manager"){

								if($sessionRole != "admin" and $sessionRole != "districtMa" and $role != "manager"){

									echo "

										<a href=\"update_processor.php?delete=".$id."\" data-role=\"button\" data-mini=\"true\" data-inline=\"true\" data-icon=\"delete\" >Delete (Cannot be undone)</a>

									";

								}

							}

						}

					?>







			</p>

	</div>

  </div>

  <div id="columnbottom">&nbsp;</div>

</div>

<div id="footer">

  <div id="footercontent">

    <p class="footphone">(623) 581-2000 Glendale, AZ  • (801) 566-6364 Sandy, UT • (801) 967-2300 Taylorsville, UT<br />

    </p>

<p>&copy; Copyright 2010 Shaolin Arts, LLC. All Rights Reserved.</p>

  </div>

</div>





</body>

</html>





<?php ob_end_flush();?>

