<?php
	require 'includes/connect.php';
	require 'includes/varDef.php';
	
	if($id){
		$sql="SELECT * FROM $tbl_name WHERE id='$id'";
		$result=mysql_query($sql);
		
		$count=mysql_num_rows($result);	
		
		if($count==1){
			mysql_query("UPDATE `$tbl_name` S