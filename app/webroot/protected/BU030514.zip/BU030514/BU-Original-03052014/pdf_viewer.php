<?php
require 'includes/check_session.php';
$sessionRole = $_SESSION['sessionRole'];
$sessionRoleStudio = $_SESSION['sessionRoleStudio'];

$sessionKungFuStatus = $_SESSION['statusSession'];
$sessionKungFuRank = $_SESSION['rankSession'];

$sessionKungFuRankDate = $_SESSION['rankDateSession'];

$sessionTaiChiStatus = $_SESSION['taiChiStatusSession'];
$sessionTaiChiRank = $_SESSION['TaiChiRankSession'];

$sessionTaiChiRankDate = $_SESSION['TaiChiRankDateSession'];

$todayDate = date('Ymd');

if ($sessionKungFuStatus == 0) {
    if(($sessionKungFuRank<12) || ($sessionKungFuRank>22)){
      $sessionKungFuRankDate = strtotime($sessionKungFuRankDate . "+ 1 Year");
      $sessionKungFuRankDate = date('Ymd', $sessionKungFuRankDate);
  }

  if((($sessionKungFuRank>11) && ($sessionKungFuRank<23)) || $sessionRole=='instructor' || $sessionRole=='manager'){
      $sessionKungFuRankDate = strtotime($sessionKungFuRankDate . "+ 2 Year");
      $sessionKungFuRankDate = date('Ymd', $sessionKungFuRankDate);
  }

  if($sessionRole=='districtMa'){
      $sessionKungFuRankDate = strtotime($sessionKungFuRankDate . "+ 4 Year");
      $sessionKungFuRankDate = date('Ymd', $sessionKungFuRankDate);
      $sessionTaiChiRankDate = date('Ymd' , strtotime('+4 year'));
  }

  if($sessionRole=='admin'){
      $sessionKungFuRankDate = date('Ymd' , strtotime('+10 year'));
      $sessionTaiChiRankDate = date('Ymd' , strtotime('+10 year'));
  }
}

if ($sessionTaiChiStatus == 0) {
    if($sessionTaiChiRank<8){
      $sessionTaiChiRankDate = strtotime($sessionTaiChiRankDate . "+ 1 Year");
      $sessionTaiChiRankDate = date('Ymd', $sessionTaiChiRankDate);
  }

  if($sessionTaiChiRank>7 || $sessionRole=='instructor' || $sessionRole=='manager'){
      $sessionTaiChiRankDate = strtotime($sessionTaiChiRankDate . "+ 2 Year");
      $sessionTaiChiRankDate = date('Ymd', $sessionTaiChiRankDate);
  }
}


require 'includes/connect.php';
require 'includes/pdfConnect.php';

	// To protect MySQL injection (more detail about MySQL injection)
$un = stripslashes($un);
$pw = stripslashes($pw);
$un = mysql_real_escape_string($un);
$pw = mysql_real_escape_string($pw);
$sql="SELECT * FROM $tbl_name WHERE un='$un' and pw='$pw'";
$result=mysql_query($sql);
$array = mysql_fetch_array($result);
$role=$array['role'];
$studio=$array['studio'];

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Shaolin Arts</title>


  <link href="p7curvitude/p7CRVboxes982_2col.css" rel="stylesheet" type="text/css" />
  <link href="p7curvitude/p7CRV04.css" rel="stylesheet" type="text/css" />
  <link href="p7pmm/p7PMMh13.css" rel="stylesheet" type="text/css" media="all" />


  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.css" />
  <link href="shaolinarts.min.css" rel="stylesheet" type="text/css" media="all" />
  <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
  <script src="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.js"></script>

  <script type="text/javascript" src="p7pmm/p7PMMscripts.js"></script>


  <meta name="Keywords" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, Utah, Arizona, Marital Arts" />
  <meta name="Description" content="Shaolin Arts is a family system of martial arts over 3,000 years old. Common western terms used to describe it would be Kung Fu, Tai Chi Chuan, Karate, Self Defense, Wushu, Animal Styles, Mixed Martial Arts, Chi Qi Gung or grappling. " />
</head>
<body>
  <div id="masthead" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, UtahArizonaMarital Arts">
    <div id="logo" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, UtahArizonaMarital Arts"><img src="images/logoanimbk.gif" alt="" width="982" height="160" /></div>
    <div id="navbar">
      <div id="navbar_inner">
        <div id="navbar_inner2">
          <div id="p7PMM_1" class="p7PMMh13">
            <ul class="p7PMM">
              <li><a href="../index.html">Home</a></li>
              <li><a ajax="false" href="pages/class-information.html">Class Information</a></li>
              <li><a ajax="false" href="pages/locations.html">Locations</a></li>
              <li><a ajax="false" href="pages/faq.html" data-ajax="false">FAQ</a></li>
              <li><a ajax="false" href="pages/events.html">Current Events</a></li>
              <li><a ajax="false" href="pages/areas-of-study.html">Areas of Study</a>
                <div>
                  <ul>
                    <li><a ajax="false" href="pages/kung-fu.html">Kung Fu</a></li>
                    <li><a ajax="false" href="pages/tai-chi.html">Tai Chi</a></li>
                    <li><a ajax="false" href="pages/self-defense.html">Self Defense</a></li>
                    <li><a ajax="false" href="pages/mma.html">Mixed Martial Arts</a></li>
                    <li><a ajax="false" href="pages/fitness.html">Fitness</a></li>
                  </ul>
                </div>
              </li>
              <li><a ajax="false" href="pages/information.html">More Information</a>
                <div>
                  <ul>
                    <li><a ajax="false" href="pages/about-us.html">About Shaolin Arts</a></li>
                    <li><a ajax="false" href="pages/events.html">Current Events</a></li>
                    <li><a ajax="false" href="pages/class-information.html">Class Information</a></li>
                    <li><a ajax="false" href="pages/locations.html">Locations</a></li>
                    <li><a ajax="false" href="pages/faq.html">FAQ</a></li>
                    <li><a ajax="false" href="pages/contact.html">Contact Us</a></li>
                    <li><a ajax="false" href="pages/history.html">History &amp; Philosophy</a></li>
                  </ul>
                </div>
              </li>
              <!--    <li><a href="#popupBasic" data-rel="popup" data-transition="slidefade">Student/Instructor Login</a></li> -->
              <li><a href="Logout.php">Log Out</a></li>
            </ul>
            <div class="p7pmmclearfloat">&nbsp;</div>
  <!--[if lte IE 6]>
<style>
.p7PMMh13 ul ul li {float:left; clear: both; width: 100%;}.p7PMMh13 {text-align: left;}.p7PMMh13, .p7PMMh13 ul ul a {zoom: 1;}
.p7PMMh13 ul ul {border: 1px solid #fff; background-color: #F90 !important;}
.p7PMMh13 ul ul a, .p7PMMh13 ul ul li {background-image: none !important;}
.p7PMMh13 ul ul a {padding: 6px 12px !important;}
.p7PMMh13 ul ul a:hover {background-color: #010101 !important;}
.p7PMMh13 ul ul a.trig_open {background-color: #000 !important; color: #fff;}
.p7PMMh13 ul ul a.trig_closed {background-image: url(p7pmm/img/pmm_east_dark.gif) !important; background-repeat: no-repeat; background-position: right center;}
</style>
<![endif]-->
  <!--[if IE 5]>
<style>.p7PMMh13, .p7PMMh13 ul ul a {height: 1%; overflow: visible !important;} .p7PMMh13 {width: 100%;}</style>
<![endif]-->
  <!--[if IE 7]>
<style>.p7PMMh13, .p7PMMh13 a{zoom:1;}.p7PMMh13 ul ul li{float:left;clear:both;width:100%;}</style>
<![endif]-->
<script type="text/javascript">
  <!--
  P7_PMMop('p7PMM_1',1,1,-10,-20,0,0,0,1,0,3,1,1,0,0);
//-->
</script>
</div>
<div class="clearfloat">&nbsp;</div>
</div>
</div>
</div>
</div>
<div class="c2_982" id="columnwrapper">
  <div id="columntop">&nbsp;</div>
  <div id="c1">
    <div class="content">
      <h2 class="topZero"><img src="images/Chuan-Fa-char-with-English.jpg" width="137" height="569" alt="chaun fa" /></h2>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p><img src="images/Chen-character-englishBlackGold.jpg" width="144" height="576" alt="chen tai chi chuan" /></p>
    </div>
  </div>
  <div id="c2">
    <div class="content">
      <h1>Shaolin Arts Library </h1>
      <h2>Welcome to resource library, please click the link bellow to see your manuals. </h2>



<!--
$sessionRole = $_SESSION['sessionRole'];
$sessionRoleStudio = $_SESSION['sessionRoleStudio'];

$sessionKungFuStatus = $_SESSION['statusSession'];
$sessionKungFuRank = $_SESSION['rankSession'];
$sessionKungFuRankDate = $_SESSION['rankDateSession'];

$sessionTaiChiStatus = $_SESSION['taiChiStatusSession'];
$sessionTaiChiRank = $_SESSION['TaiChiRankSession'];
$sessionTaiChiRankDate = $_SESSION['TaiChiRankDateSession'];

 -->
<!-- <a href="pdf-delivery.php" target="_blank">test</a> -->

<?php


// echo "

// Role: $sessionRole<br />
// Role Studio: $sessionRoleStudio<br />
// Kung Fu Status: $sessionKungFuStatus<br />
// Kung Fu Rank: $sessionKungFuRank<br />
// Kung Fu Rank Date: $sessionKungFuRankDate<br />
// Tai Chi Status: $sessionTaiChiStatus<br />
// Tai Chi Rank: $sessionTaiChiRank<br />
// Tai Chi Rank Date: $sessionTaiChiRankDate<br />
// Today's Date: $todayDate<br />
// Session Kung Fu Date: $sessionKungFuRankDate<br />
// Session Tai chi Date: $sessionTaiChiRankDate<br />

// ";


if($todayDate<$sessionKungFuRankDate || $todayDate<$sessionTaiChiRankDate){
if ($sessionKungFuStatus == 0) {
  if($todayDate<$sessionKungFuRankDate){
      echo"<h2>Kung Fu</h2>";
      echo"<ol>";

        // Kung Fu Beginners
      echo "<li><a href=\"pdf/ShaolinWuLingXingBeg-REV011114-acGE5ScPNQ.pdf\"\" target=\"_blank\">".$pdfInfo[3][0]."</a></li>";


      if (($sessionKungFuRank>3 && $sessionKungFuRank<23) || ($sessionKungFuRank>25)) {
        // Kung Fu Intermediate
        echo "<li><a href=\"pdf/ShaolinWuLingXingInt-REV011114-gB5zP2A2WJ.pdf\" target=\"_blank\">".$pdfInfo[3][1]."</a></li>";
      }

      if (($sessionKungFuRank>7 && $sessionKungFuRank<23) || ($sessionKungFuRank>29)) {
        // Kung Fu Advanced
        echo "<li><a href=\"pdf/ShaolinWuLingXingAd-REV011114-5rmh9Wwfxd.pdf\" target=\"_blank\">".$pdfInfo[3][2]."</a></li>";
      }


      // if ($sessionKungFuRank>11 && $sessionKungFuRank<23){
      //   // Kung Fu Black Beguinner
      //   echo "<li><a href=\"pdf/".$pdfInfo[0][7]."\" target=\"_blank\">".$pdfInfo[3][7]."</a></li>";
      // }

      // if ($sessionKungFuRank>13 && $sessionKungFuRank<23) {
      //   // Kung Fu Black Advanced
      //   echo "<li><a href=\"pdf/".$pdfInfo[0][8]."\" target=\"_blank\">".$pdfInfo[3][8]."</a></li>";
      // }

      if ($sessionKungFuRank>11 && $sessionKungFuRank<23) {
        // Kung Fu Post Black
        echo "<li><a href=\"pdf/ShaolinWuLingXingPostBlack-REV011114-28cXPcpbNf.pdf\" target=\"_blank\">".$pdfInfo[3][8]."</a></li>";
      }
      echo"</ol>";


  }else{
    echo "<h2>Your access to the Kung Fu materials has expired, please give the office a call.</h2>";
  }
}

if($todayDate<$sessionKungFuRankDate && $sessionKungFuStatus == 0 && $sessionKungFuRank>11 && $sessionKungFuRank<23){
  echo"<h2>Tai Chi</h2>";
  echo"<ol>";

  // Tai Chi Beginners
  echo "<li><a href=\"pdf/TaiChiChuanInternet-REV011114-2B6aukdVzP-.pdf\" target=\"_blank\">Tai Chi</a></li>";
}


if ($sessionTaiChiStatus==0) {
  if($todayDate<$sessionTaiChiRankDate){

  echo"<h2>Tai Chi</h2>";
  echo"<ol>";

  // Tai Chi Beginners
  echo "<li><a href=\"pdf/TaiChiChuanInternet-REV011114-2B6aukdVzP-.pdf\" target=\"_blank\">Tai Chi</a></li>";

  // if (($sessionTaiChiRank>1 && $sessionTaiChiRank<5) ||  ($sessionTaiChiRank>5)){
  // // Tai Chi Intermediate
  //   echo "<li><a href=\"pdf/".$pdfInfo[0][4]."\" target=\"_blank\">".$pdfInfo[3][4]."</a></li>";
  // }

  // if (($sessionTaiChiRank>2 && $sessionTaiChiRank<5) ||  ($sessionTaiChiRank>6)) {
  // // Tai Chi Advanced
  //   echo "<li><a href=\"pdf/".$pdfInfo[0][5]."\" target=\"_blank\">".$pdfInfo[3][5]."</a></li>";
  // }
  // if (($sessionTaiChiRank>2 && $sessionTaiChiRank<5) ||  ($sessionTaiChiRank>6)) {
  // // Tai Chi Advanced
  //   echo "<li><a href=\"pdf/".$pdfInfo[0][5]."\" target=\"_blank\">".$pdfInfo[3][5]."</a></li>";

  if (($sessionTaiChiRank>2 && $sessionTaiChiRank<5) ||  ($sessionTaiChiRank>6)) {
  // Tai Chi Advanced
    echo "<li><a href=\"pdf/TaiChiChuanPostBlack-REV011114-bbDuEzYXd9-.pdf\" target=\"_blank\">Tai Chi Black</a></li>";
  }


  echo"</ol>";


  }else{
    echo "<h2>Your access to the Tai Chi materials has expired, please give the office a call.</h2>";
  }
}
  // Instructor's College

  if ($sessionRole!=student) {
    echo"<h2>Instructor's College</h2>";
    echo"<ol>";
    echo "<li><a href=\"pdf/InstructorCollegeManual-REV011114-rHtnZ6T3q4.pdf\" target=\"_blank\">".$pdfInfo[3][6]."</a></li>";

    echo"</ol>";
  }

}else{
  echo "<h2>Your access to these materials has expired, please give the office a call.</h2>";
}
?>





    </div>
  </div>
  <div id="columnbottom">&nbsp;</div>
</div>
<div id="footer">
  <div id="footercontent">
    <p class="footphone">(623) 581-2000 Glendale, AZ  • (801) 566-6364 Sandy, UT • (801) 967-2300 Taylorsville, UT<br />
    </p>
    <p>&copy; Copyright 2010 Shaolin Arts, LLC. All Rights Reserved.</p>
  </div>
</div>


</body>
</html>
