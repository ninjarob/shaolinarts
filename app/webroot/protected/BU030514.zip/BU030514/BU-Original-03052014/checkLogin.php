<?php

	require 'includes/connect.php';
	require 'includes/varDef.php';

	// To protect MySQL injection (more detail about MySQL injection)
	$un = stripslashes($un);
	$pw = stripslashes($pw);
	$un = mysql_real_escape_string($un);
	$pw = mysql_real_escape_string($pw);
	$sql="SELECT * FROM $tbl_name WHERE un='$un' and pw='$pw'";
	$result=mysql_query($sql);

 
//$array = mysql_fetch_array($result);
//$level = $array['level'];
//$active = $array['active'];

/*$lvl_1_lenght = '3 days';
$lvl_2_lenght = '10 days';
$lvl_3_lenght = '30 days';

$date = $array['date'];
$date = strtotime($date. '+'.  $lvl_1_lenght);
$date = date('Y.m.d', $date);

$todayDate = date('Y.m.d');*/

	// Mysql_num_row is counting table row
	$count=mysql_num_rows($result);

	if($count==1){
		session_start();
		$_SESSION['un'] = 1;
		
		header("location:admin.php");
	}

ob_end_flush();

?>

