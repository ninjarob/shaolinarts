<!-- PHP Delivery -->

<?php

   //header("location:http://shaolinarts.com/pdf/InstructorCollegeManual-REV011114-rHtnZ6T3q4.pdf.php");
?>


<h1>Test</h1>