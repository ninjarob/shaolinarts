<?php

	require 'includes/connect.php';
	
	require 'includes/varDef.php';

	mysql_close($con); 
?>