<?php
	require 'includes/check_session.php';
	$sessionRole = $_SESSION['sessionRole'];
	$sessionRoleStudio = $_SESSION['sessionRoleStudio'];

	$StudioSession = $_SESSION['StudioSession'];
	$TaiChiStudioSession = $_SESSION['TaiChiStudioSession'];

	require 'includes/roleCheck.php';
	require 'includes/connect.php';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Shaolin Arts</title>


<link href="p7curvitude/p7CRVboxes982_2col.css" rel="stylesheet" type="text/css" />
<link href="p7curvitude/p7CRV04.css" rel="stylesheet" type="text/css" />
<link href="p7pmm/p7PMMh13.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="p7pmm/p7PMMscripts.js"></script>


	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.css" />
		<link href="shaolinarts.min.css" rel="stylesheet" type="text/css" media="all" />


	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.js"></script>

<meta name="Keywords" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, Utah, Arizona, Marital Arts" />
<meta name="Description" content="Shaolin Arts is a family system of martial arts over 3,000 years old. Common western terms used to describe it would be Kung Fu, Tai Chi Chuan, Karate, Self Defense, Wushu, Animal Styles, Mixed Martial Arts, Chi Qi Gung or grappling. " />


</head>
<body>
<div id="masthead" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, UtahArizonaMarital Arts">
  <div id="logo" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, UtahArizonaMarital Arts"><img src="images/logoanimbk.gif" alt="" width="982" height="160" /></div>
  <div id="navbar">
    <div id="navbar_inner">
      <div id="navbar_inner2">
<div id="p7PMM_1" class="p7PMMh13">
  <ul class="p7PMM">
    <li><a href="http://www.shaolinarts.com">Home</a></li>
    <li><a href="pages/class-information.html">Class Information</a></li>
    <li><a href="pages/locations.html">Locations</a></li>
    <li><a href="pages/faq.html">FAQ</a></li>
    <li><a href="pages/events.html">Current Events</a></li>
    <li><a href="pages/areas-of-study.html">Areas of Study</a>
      <div>
        <ul>
          <li><a href="pages/kung-fu.html">Kung Fu</a></li>
          <li><a href="pages/tai-chi.html">Tai Chi</a></li>
          <li><a href="pages/self-defense.html">Self Defense</a></li>
          <li><a href="pages/mma.html">Mixed Martial Arts</a></li>
          <li><a href="pages/fitness.html">Fitness</a></li>
        </ul>
      </div>
    </li>
    <li><a href="pages/information.html">More Information</a>
      <div>
        <ul>
          <li><a href="pages/about-us.html">About Shaolin Arts</a></li>
          <li><a href="pages/events.html">Current Events</a></li>
          <li><a href="pages/class-information.html">Class Information</a></li>
          <li><a href="pages/locations.html">Locations</a></li>
          <li><a href="pages/faq.html">FAQ</a></li>
          <li><a href="pages/contact.html">Contact Us</a></li>
          <li><a href="pages/history.html">History &amp; Philosophy</a></li>
        </ul>
      </div>
    </li>
     <li><a href="Logout.php">Log Out</a></li>
  </ul>
  <div class="p7pmmclearfloat">&nbsp;</div>
  <!--[if lte IE 6]>
<style>
.p7PMMh13 ul ul li {float:left; clear: both; width: 100%;}.p7PMMh13 {text-align: left;}.p7PMMh13, .p7PMMh13 ul ul a {zoom: 1;}
.p7PMMh13 ul ul {border: 1px solid #fff; background-color: #F90 !important;}
.p7PMMh13 ul ul a, .p7PMMh13 ul ul li {background-image: none !important;}
.p7PMMh13 ul ul a {padding: 6px 12px !important;}
.p7PMMh13 ul ul a:hover {background-color: #010101 !important;}
.p7PMMh13 ul ul a.trig_open {background-color: #000 !important; color: #fff;}
.p7PMMh13 ul ul a.trig_closed {background-image: url(p7pmm/img/pmm_east_dark.gif) !important; background-repeat: no-repeat; background-position: right center;}
</style>
<![endif]-->
  <!--[if IE 5]>
<style>.p7PMMh13, .p7PMMh13 ul ul a {height: 1%; overflow: visible !important;} .p7PMMh13 {width: 100%;}</style>
<![endif]-->
  <!--[if IE 7]>
<style>.p7PMMh13, .p7PMMh13 a{zoom:1;}.p7PMMh13 ul ul li{float:left;clear:both;width:100%;}</style>
<![endif]-->
  <script type="text/javascript">
<!--
P7_PMMop('p7PMM_1',1,1,-10,-20,0,0,0,1,0,3,1,1,0,0);
//-->
  </script>
</div>
<div class="clearfloat">&nbsp;</div>
      </div>
    </div>
  </div>
</div>
  <div class="c2_982" id="columnwrapper">
  <div id="columntop">&nbsp;</div>
  <div id="c1">
    <div class="content">
      <h2 class="topZero"><img src="images/Chuan-Fa-char-with-English.jpg" width="137" height="569" alt="chaun fa" /></h2>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p><img src="images/Chen-character-englishBlackGold.jpg" width="144" height="576" alt="chen tai chi chuan" /></p>
    </div>
  </div>
  <div id="c2">
    <div class="content">

		<p style="margin-bottom: 20px;">
    	<?php

// echo " S Role: $sessionRole <br /> S Role Studio: $sessionRoleStudio <br /> S KF Studio : $TaiChiStudioSession <br /> S TC Studio: $TaiChiStudioSession";

			if($sessionRole=='admin' || $sessionRole=='districtMa' || $sessionRole=='manager'){
				echo "
					<a href=\"edit_user.php\"  data-ajax=\"false\" data-role=\"button\" data-mini=\"true\" data-inline=\"true\" data-icon=\"plus\" >Add User</a>
				";
			}
		?>
			<a href="pdf_viewer.php" target="_blank"  data-ajax="false" data-role="button" data-mini="true" data-inline="true" >Visit the library</a>
			</p>


    	<ol  data-role="listview" data-split-icon="delete" data-split-theme="a" data-inset="true" data-filter="true" style="margin-top: 15px;">

		<?php

			$i=0;
			while ($i < $count) {

				$id=mysql_result($result,$i,"id");
				//$date=mysql_result($result,$i,"rankDate");
				//$date = strtotime($date);
				//$date = date('d/m/Y', $date);

				//$lvl_1_lenght = '3 days';
				//$lvl_2_lenght = '10 days';
				//$lvl_3_lenght = '30 days';

				//$compareDate=mysql_result($result,$i,"rankDate");
				//$compareDate = strtotime($compareDate);
				//$compareDate = date('Y.m.d', $compareDate);

				$fname=mysql_result($result,$i,"name");
				$lname=mysql_result($result,$i,"lastName");
				//$email=mysql_result($result,$i,"email");
				$birthday=mysql_result($result,$i,"birthday");
				$birthday = strtotime($birthday);
				$birthday = date('Y.m.d', $birthday);
				$todayDate = date('Y.m.d');
				$age = $todayDate - $birthday;

				//$dueDate=mysql_result($result,$i,"dueDate");
				//$dueDate = strtotime($dueDate);
				//$dueDate = date('d/m', $dueDate);

				$studio=mysql_result($result,$i,"studio");
				$taiChiStudio=mysql_result($result,$i,"taiChiStudio");
				//$program=mysql_result($result,$i,"program");
				$rank=mysql_result($result,$i,"rank");
				$status=mysql_result($result,$i,"status");
				$TaiChiRank=mysql_result($result,$i,"TaiChiRank");
				$taiChiStatus=mysql_result($result,$i,"taiChiStatus");
				$role=mysql_result($result,$i,"role");





				if($sessionRole=='admin'){
					require 'includes/admin_content.php';
				}

				if($sessionRole=='districtMa'){
					if($sessionRoleStudio==1){
						if($studio==1 || $taiChiStudio==1 || $taiChiStudio==0 && $studio==0){
							require 'includes/admin_content.php';
						}
					}
					if($sessionRoleStudio==2 || $sessionRoleStudio==3 || $sessionRoleStudio==4){
						if($studio > 1 || $taiChiStudio > 1 || $studio==0 && $taiChiStudio==0){
							require 'includes/admin_content.php';
						}
					}
				}

				if($sessionRole=='manager'){
					if($sessionRoleStudio==$studio || $sessionRoleStudio==$taiChiStudio || $studio==0 && $taiChiStudio==0){
						require 'includes/admin_content.php';
					}

					if($sessionRoleStudio==4 && $studio > 1 || $sessionRoleStudio==4 && $taiChiStudio > 1){
						require 'includes/admin_content.php';
					}
				}

				if($sessionRole=='instructor'){
					if($sessionRoleStudio==$studio || $sessionRoleStudio==$taiChiStudio || $studio==0 && $taiChiStudio==0){
						require 'includes/admin_content.php';
					}

					if($sessionRoleStudio==4 && $studio > 1 || $sessionRoleStudio==4 && $taiChiStudio > 1 || $studio==0 && $taiChiStudio==0){
						require 'includes/admin_content.php';
					}
				}

				$i++;

			}
			?>

			</ol>


	</div>
  </div>
  <div id="columnbottom">&nbsp;</div>
</div>
<div id="footer">
  <div id="footercontent">
    <p class="footphone">(623) 581-2000 Glendale, AZ  • (801) 566-6364 Sandy, UT • (801) 967-2300 Taylorsville, UT<br />
    </p>
<p>&copy; Copyright 2010 Shaolin Arts, LLC. All Rights Reserved.</p>
  </div>
</div>


</body>
</html>






<?php ob_end_flush();?>
