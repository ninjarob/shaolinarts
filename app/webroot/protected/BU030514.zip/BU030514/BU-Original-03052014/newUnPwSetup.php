<?php
	require 'includes/connect.php';
	require 'includes/varDef.php';

	$name = stripslashes($name);
	$lastName = stripslashes($lastName);
	$email = stripslashes($email);

	$passwordKey=$_GET['K'];
	$key=$_POST['pwk'];

	if($passwordKey){
		$message = "Please enter a User Name and password for your account.";
	}else{
		if($un && $pw && $key){
			$sql="SELECT * FROM $tbl_name WHERE un='$un'";
			$result=mysql_query($sql);
			$array = mysql_fetch_array($result);
			$count=mysql_num_rows($result);
			if($count==1){
				$message = "The User Name you chose is not available, please choose a different one.";
			}else{
				mysql_query("UPDATE `$tbl_name` SET un='$un', pw='$pw' WHERE passwordKey='$key';")or die(mysql_error("Database Error"));
				$message = "You have successfully updated your User Name and Password.";
			}
		}else{
			header("location:http://shaolinarts.com/newMember.php");
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>New Member</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.css" />
	<link href="shaolinarts.min.css" rel="stylesheet" type="text/css" media="all" />
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.js"></script>
</head>
<body>
<form name="form1" method="post" action="newUnPwSetup.php"  data-ajax="false">
	<div style="width: 500px; margin: 200px auto;" data-role="content">
		<div data-role="header">
			<h1>New Member Access</h1>
		</div>
		<ul data-role="listview" data-inset="true">


			<?php
				if($message){
					echo "
						<li>
							<label style\"color: #f00;\">".$message."</label>
						</li>
					";
				}
			?>

			<?php

				if($passwordKey){
			?>

				<li data-role="fieldcontain">
					<label for="un" style="display: block; float: left; width: 150px; font-weight: bold;">New User Name:</label>
					<input name="un" type="text" id="un" data-mini="true"  data-inline="true" />
				</li>
				<li data-role="fieldcontain">
					<label for="pw" style="display: block; float: left; width: 150px; font-weight: bold;">New Password:</label>
					<input name="pw" type="password" id="pw" data-mini="true"  data-inline="true" />
				</li>
				<li>
					<input type="submit" name="Submit" value="Submit"  data-mini="true" data-inline="true" data-icon="plus" />
					<input type="hidden" name="pwk" value="<? echo "$passwordKey"; ?>" />
				</li>

			<?php
				}else{
			?>

				<li>
					<a href="login.php">Log In</a>
				</li>

			<?php
				}
			?>
		</ul>
	</div>
</form>

<script type="text/javascript">
	$(document).ready(function() {
		$('#myusername').focus();
	});
</script>
</body>
</html>