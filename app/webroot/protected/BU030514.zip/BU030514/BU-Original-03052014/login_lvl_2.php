<?php
session_start();
if(!isset($_SESSION['un'])){
	header("location:index.html");
}

?>

<html>
<body>
	<br />
	<h1>Level 2</h1>
	<a href="Logout.php">Log Out</a>
</body>
</html>