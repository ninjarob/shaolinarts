<?php
	require 'includes/connect.php';
	require 'includes/varDef.php';
	
	// To protect MySQL injection (more detail about MySQL injection)
	$name = stripslashes($name);
	$lastName = stripslashes($lastName);
	$email = stripslashes($email);
	$birthday = stripslashes($birthday);
	
	$sql="SELECT * FROM $tbl_name WHERE name='$name' and lastName='$lastName' and email='$email' and birthday='$birthday'";
	//$sql="SELECT * FROM $tbl_name WHERE email='$email'";

	$result=mysql_query($sql);
	$count=mysql_num_rows($result);	
	$array = mysql_fetch_array($result);
	$id=$array["id"];
	$firstName=$array["firstName"];
	$lastName=$array["lastName"];
	
	if($count==1){
		$passwordKey = rand();
		mysql_query("UPDATE `$tbl_name` SET passwordKey='$passwordKey' WHERE id='$id';") or die(mysql_error("Database Error"));
		
		$from = "noreplay@shaolinarts.com";
		$to = $email;
		$subject = "Shaolin Arts, Password Reset - Do not reply";
		$message = "Dear $firstName, \n We have received a request to change your account's password. If you did not request this change, you can disregard this message. \n \n If you wish to change your password, please follow the link bellow: \n \n http://shaolinarts.com/passwordProcessor.php?key=".$passwordKey." \n \n Please if you have any questions contact the office. \n \n The Shaolin Arts team.";
		$headers = "From:" . $from;
		mail($to,$subject,$message,$headers);

		
		//$message= $id;
		$message="We have sent an email to your account with instructions on how to update your username and password.";
	
	}else{
		$message="Sorry but the I cannot find you";
	}

	
?>

<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Password Manager</title>
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.css" />
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	


	
</head>
<body>

	<div style="width: 500px; margin: 200px auto;" data-role="content">
	
			<ul data-role="listview" data-inset="true">
				<li data-role="fieldcontain">
					<?php echo $message; ?>
				</li>
			</ul>
	</div>


</body>
</html>

