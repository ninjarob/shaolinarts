<?php
	require 'includes/connect.php';
	
	$id=$_GET['id'];
	
	mysql_query("DELETE FROM $tbl_name WHERE id=$id;") or die(mysql_error());
	$result=mysql_query($sql);
	
	// Mysql_num_row is counting table row
	$count=mysql_num_rows($result);	
	
	
	header("location:admin.php");

	mysql_close($con);
?>