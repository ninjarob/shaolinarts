<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Bad Password</title>
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.css" />
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.js"></script>
</head>
<body>

<div data-role="dialog">
		<div data-role="content">
			<h1>Wrong User name or Password</h1>
			<p>Please check the information and try again</p>
			<a href="dialog/index.html" data-role="button" data-rel="back" data-theme="b">OK, I'll try again.</a>       
		</div>
	</div>
</body>
</html>