<?php

	require 'includes/connect.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Shaolin Arts</title>


<link href="p7curvitude/p7CRVboxes982_2col.css" rel="stylesheet" type="text/css" />
<link href="p7curvitude/p7CRV04.css" rel="stylesheet" type="text/css" />
<link href="p7pmm/p7PMMh13.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="p7pmm/p7PMMscripts.js"></script>

	


	<meta name="viewport" content="width=device-width, initial-scale=1"> 
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.css" />
	
	<link rel="stylesheet" href="validation/css/validationEngine.jquery.css" type="text/css"/>
	<link rel="stylesheet" href="validation/css/template.css" type="text/css"/>

	
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.js"></script>

	<script src="validation/js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>
	<script src="validation/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>

<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#form1").validationEngine('attach');
		});
	</script>

<meta name="Keywords" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, Utah, Arizona, Marital Arts" />
<meta name="Description" content="Shaolin Arts is a family system of martial arts over 3,000 years old. Common western terms used to describe it would be Kung Fu, Tai Chi Chuan, Karate, Self Defense, Wushu, Animal Styles, Mixed Martial Arts, Chi Qi Gung or grappling. " />

<style type="text/css">
	
</style>




</head>
<body>
<div id="masthead" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, UtahArizonaMarital Arts">
  <div id="logo" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, UtahArizonaMarital Arts"><img src="images/logoanimbk.gif" alt="" width="982" height="160" /></div>
  <div id="navbar">
    <div id="navbar_inner">      
      <div id="navbar_inner2">
<div id="p7PMM_1" class="p7PMMh13">
  <ul class="p7PMM">
    <li><a href="../index.html">Home</a></li>
    <li><a href="pages/class-information.html">Class Information</a></li>
    <li><a href="pages/locations.html">Locations</a></li>
    <li><a href="pages/faq.html">FAQ</a></li>
    <li><a href="pages/events.html">Current Events</a></li>
    <li><a href="pages/areas-of-study.html">Areas of Study</a>
      <div>
        <ul>
          <li><a href="pages/kung-fu.html">Kung Fu</a></li>
          <li><a href="pages/tai-chi.html">Tai Chi</a></li>
          <li><a href="pages/self-defense.html">Self Defense</a></li>
          <li><a href="pages/mma.html">Mixed Martial Arts</a></li>
          <li><a href="pages/fitness.html">Fitness</a></li>
        </ul>
      </div>
    </li>
    <li><a href="pages/information.html">More Information</a>
      <div>
        <ul>
          <li><a href="pages/about-us.html">About Shaolin Arts</a></li>
          <li><a href="pages/events.html">Current Events</a></li>
          <li><a href="pages/class-information.html">Class Information</a></li>
          <li><a href="pages/locations.html">Locations</a></li>
          <li><a href="pages/faq.html">FAQ</a></li>
          <li><a href="pages/contact.html">Contact Us</a></li>
          <li><a href="pages/history.html">History &amp; Philosophy</a></li>
        </ul>
      </div>
    </li>
     <li><a href="login.php">Student/Instructor Login</a></li>
  </ul>
  <div class="p7pmmclearfloat">&nbsp;</div>
  <!--[if lte IE 6]>
<style>
.p7PMMh13 ul ul li {float:left; clear: both; width: 100%;}.p7PMMh13 {text-align: left;}.p7PMMh13, .p7PMMh13 ul ul a {zoom: 1;}
.p7PMMh13 ul ul {border: 1px solid #fff; background-color: #F90 !important;}
.p7PMMh13 ul ul a, .p7PMMh13 ul ul li {background-image: none !important;}
.p7PMMh13 ul ul a {padding: 6px 12px !important;}
.p7PMMh13 ul ul a:hover {background-color: #010101 !important;}
.p7PMMh13 ul ul a.trig_open {background-color: #000 !important; color: #fff;}
.p7PMMh13 ul ul a.trig_closed {background-image: url(p7pmm/img/pmm_east_dark.gif) !important; background-repeat: no-repeat; background-position: right center;}
</style>
<![endif]-->
  <!--[if IE 5]>
<style>.p7PMMh13, .p7PMMh13 ul ul a {height: 1%; overflow: visible !important;} .p7PMMh13 {width: 100%;}</style>
<![endif]-->
  <!--[if IE 7]>
<style>.p7PMMh13, .p7PMMh13 a{zoom:1;}.p7PMMh13 ul ul li{float:left;clear:both;width:100%;}</style>
<![endif]-->
  <script type="text/javascript">
<!--
P7_PMMop('p7PMM_1',1,1,-10,-20,0,0,0,1,0,3,1,1,0,0);
//-->
  </script>
</div>
<div class="clearfloat">&nbsp;</div>
      </div>
    </div>
  </div>
</div>
  <div class="c2_982" id="columnwrapper">
  <div id="columntop">&nbsp;</div>
  <div id="c1">
    <div class="content">
      <h2 class="topZero"><img src="images/Chuan-Fa-char-with-English.jpg" width="137" height="569" alt="chaun fa" /></h2>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p><img src="images/Chen-character-englishBlackGold.jpg" width="144" height="576" alt="chen tai chi chuan" /></p>
    </div>
  </div>
  <div id="c2">
    <div class="content">
    	
    	
<h1>Add Student</h1>
		
	<form name="form1" id="form1" method="post" data-ajax="false" action="insert.php">
    <ul data-role="listview" data-inset="true">
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">First Name:</label>
            <input name="name" type="text" class="validate[required,custom[onlyLetterNumber]] text-input" id="name" data-mini="true" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Last Name:</label>
            <input name="lastName" type="text" id="lastName" class="validate[required,custom[onlyLetterNumber]] text-input" data-mini="true" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Home Phone:</label>
            <input name="homePhone" type="tel" id="homePhone" class="validate[custom[phone]] text-input" data-mini="true" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Cell Phone:</label>
            <input name="cellPhone" type="tel" id="cellPhone" class="validate[custom[phone]] text-input" data-mini="true" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Work Phone:</label>
            <input name="workPhone" type="tel" id="workPhone" class="validate[custom[phone]] text-input" data-mini="true" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">email:</label>
            <input name="email" type="email" id="email"  class="validate[required,custom[email]] text-input" data-mini="true" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Address:</label>
            <input name="addres" type="text" id="addres" class="validate[required,custom[onlyLetterNumber]] text-input" data-mini="true" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">City:</label>
            <input name="city" type="text" id="city" class="validate[required,custom[onlyLetterNumber]] text-input" data-mini="true" data-inline="true"/>
        </li>
		
		
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">state:</label>
			<select name="state" id="state" data-mini="true" data-inline="true" name="State">
				<option selected="selected" value="">Select a State</option>
				<option value="AL" selected="selected">Alabama</option>
				<option value="AK">Alaska</option>
				<option value="AZ">Arizona</option>
				<option value="AR">Arkansas</option>
				<option value="CA">California</option>
				<option value="CO">Colorado</option>
				<option value="CT">Connecticut</option>
				<option value="DE">Delaware</option>
				<option value="DC">District Of Columbia</option>
				<option value="FL">Florida</option>
				<option value="GA">Georgia</option>
				<option value="HI">Hawaii</option>
				<option value="ID">Idaho</option>
				<option value="IL">Illinois</option>
				<option value="IN">Indiana</option>
				<option value="IA">Iowa</option>
				<option value="KS">Kansas</option>
				<option value="KY">Kentucky</option>
				<option value="LA">Louisiana</option>
				<option value="ME">Maine</option>
				<option value="MD">Maryland</option>
				<option value="MA">Massachusetts</option>
				<option value="MI">Michigan</option>
				<option value="MN">Minnesota</option>
				<option value="MS">Mississippi</option>
				<option value="MO">Missouri</option>
				<option value="MT">Montana</option>
				<option value="NE">Nebraska</option>
				<option value="NV">Nevada</option>
				<option value="NH">New Hampshire</option>
				<option value="NJ">New Jersey</option>
				<option value="NM">New Mexico</option>
				<option value="NY">New York</option>
				<option value="NC">North Carolina</option>
				<option value="ND">North Dakota</option>
				<option value="OH">Ohio</option>
				<option value="OK">Oklahoma</option>
				<option value="OR">Oregon</option>
				<option value="PA">Pennsylvania</option>
				<option value="RI">Rhode Island</option>
				<option value="SC">South Carolina</option>
				<option value="SD">South Dakota</option>
				<option value="TN">Tennessee</option>
				<option value="TX">Texas</option>
				<option value="UT">Utah</option>
				<option value="VT">Vermont</option>
				<option value="VA">Virginia</option>
				<option value="WA">Washington</option>
				<option value="WV">West Virginia</option>
				<option value="WI">Wisconsin</option>
				<option value="WY">Wyoming</option>
			</select>	
        </li>
		
		
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">zip:</label>
            <input name="zip" type="text" id="zip" class="validate[required,custom[number]] text-input" data-mini="true" data-inline="true"/>
        </li>
		
		
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Birthday:</label>
            <input name="birthday" type="date" id="birthday" class="validate[required,custom[date]] text-input" value="asd" data-mini="true" data-inline="true"/>
        </li>
		
		
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Spouse/Guardan:</label>
            <input name="spouseGuardian" type="text" id="spouseGuardian" class="validate[custom[onlyLetterNumber]] text-input" data-mini="true" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Spouse/Guardian Phone:</label>
            <input name="sgPhone" type="tel" id="sgPhone" data-mini="true" class="validate[custom[phone]] text-input" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Spouse/Guardian Cell Phone:</label>
            <input name="sgCellPhone" type="tel" id="sgCellPhone" class="validate[custom[phone]] text-input" data-mini="true" data-inline="true"/>
        </li>
		
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Start Date:</label>
            <input name="startDate" type="date" data-clear-btn="false" class="validate[required,custom[date]] text-input"  id="startDate" data-mini="true" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Due Date:</label>
            <input name="dueDate" type="date" id="dueDate" class="validate[custom[date]] text-input" data-mini="true" data-inline="true"/>
        </li>
		
		
		
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Studio:</label>
			<select name="studio" data-mini="true" data-inline="true">
			  <option value="1">Glendale, AZ</option>
			  <option value="2">Sandy, UT</option>
			  <option value="3">Taylorsville,UT</option>
			</select>			
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Program:</label>
			<select name="program" data-mini="true" data-inline="true">
			  <option value="1">Tai Chi</option>
			  <option value="2">Kung Fu</option>
			</select>	
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Long Term Program:</label>
			<select name="longTermProgram" data-mini="true" data-inline="true">
			  <option value="1">BPS</option>
			  <option value="2">contract</option>
			  <option value="3">3 Months</option>
			  <option value="4">6 Months</option>
			  <option value="5">12 Months</option>
			</select>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Lesson Type:</label>
			<select name="lessonType" data-mini="true" data-inline="true">
			  <option value="1">Group</option>
			  <option value="2">Private</option>
			  <option value="3">Accelerated</option>
			  <option value="3">BSP</option>
			</select>	
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Rank:</label>
        	<select name="rank" data-mini="true" data-inline="true">
			  <option value="1">White</option>
			  <option value="2">Yellow</option>
			  <option value="3">Orange</option>
			  <option value="4">Purple</option>
			  <option value="5">Blue</option>
			  <option value="6">Blue Advanced</option>
			  <option value="7">Green</option>
			  <option value="8">Green Advanced</option>
			  <option value="9">Red</option>
			  <option value="10">Brown</option>
			  <option value="11">Brown Advanced</option>
			  <option value="12">Sidi</option>
			  <option value="13">Sidi Dai Lou</option>
			  <option value="14">Si Hing</option>
			  <option value="15">Si Hing Dai Lou</option>
			  <option value="16">Sisuk</option>
			  <option value="17">Sisuk Dai Lou</option>
			  <option value="18">Sifu</option>
			  <option value="19">Si Bok</option>
			  <option value="20">Si Gung</option>
			  <option value="21">Si Tai Gung</option>
			  <option value="22">Si Jo</option>
			</select>
        </li>
		
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Rank Date:</label>
            <input name="rankDate" type="date" id="rankDate"  class="validate[custom[date]] text-input" data-mini="true" data-inline="true"/>
        </li>
		
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Status:</label>
            <select name="status" data-mini="true" data-inline="true">
			  <option value="0">Active</option>
			  <option value="1">Not Active</option>
			  <option value="2">Non Student</option>
			</select>

        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 150px;">Student ID:</label>
            <input name="studentID" type="text" id="studentID" data-mini="true" class="validate[custom[onlyLetterNumber]] text-input" data-inline="true"/>
        </li>
		
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 100px;">ICE Name:</label>
            <input name="ice1" type="text" id="ice1" data-mini="true" class="validate[custom[onlyLetterNumber]] text-input" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 100px;">ICE Phone:</label>
            <input name="ice1Phone" type="tel" id="ice1Phone" data-mini="true" class="validate[custom[phone]] text-input" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 100px;">ICE Cell Phone:</label>
            <input name="ice1CellPhone" type="tel" id="ice1CellPhone" data-mini="true" class="validate[custom[phone]] text-input" data-inline="true"/>
        </li>
		
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 100px;">ICE Name 2:</label>
            <input name="ice2" type="text" id="ice2" data-mini="true" class="validate[custom[onlyLetterNumber]] text-input" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 100px;">ICE Phone 2:</label>
            <input name="ice2Phone" type="tel" id="ice2Phone" data-mini="true" class="validate[custom[phone]] text-input" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 100px;">ICE Cell Phone 2:</label>
            <input name="ice2CellPhone" type="tel" id="ice2CellPhone" data-mini="true" class="validate[custom[phone]] text-input" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 100px;">ICE Name 3:</label>
            <input name="ice3" type="text" id="ice3" data-mini="true" class="validate[custom[onlyLetterNumber]] text-input" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 100px;">ICE Phone 3:</label>
            <input name="ice3Phone" type="tel" id="ice3Phone" data-mini="true" class="validate[custom[phone]] text-input" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 100px;">ICE Cell Phone 3:</label>
            <input name="ice3CellPhone" type="tel" id="ice3CellPhone" data-mini="true" class="validate[custom[phone]] text-input" data-inline="true"/>
        </li>
		
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 100px;">User Name:</label>
            <input name="un" type="text" id="un" data-mini="true" data-inline="true"/>
        </li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 100px;">Password:</label>
            <input name="pw" type="text" id="pw" data-mini="true" data-inline="true"/>
        </li>

		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 100px;">Notes:</label>
            <input name="notes" type="text" id="notes" data-mini="true" data-inline="true"/>
        </li>

        <li>
			<input  style="margin-bottom: 20px;" type="submit" name="Add" value="add"  data-mini="true" data-inline="true" data-icon="plus" />
		</li>
    </ul>
	</form>

	<p style="margin-bottom: 20px;"><a href="admin.php"  data-role="button" data-mini="true" data-inline="true" data-icon="back" >Return to the admin tool</a></p>
	
	
	</div>
  </div>
  <div id="columnbottom">&nbsp;</div>
</div>
<div id="footer">
  <div id="footercontent">
    <p class="footphone">(623) 581-2000 Glendale, AZ  • (801) 566-6364 Sandy, UT • (801) 967-2300 Taylorsville, UT<br />
    </p>
<p>&copy; Copyright 2010 Shaolin Arts, LLC. All Rights Reserved.</p>
  </div>
</div>


</body>
</html>


<?php ob_end_flush();?>

    	
