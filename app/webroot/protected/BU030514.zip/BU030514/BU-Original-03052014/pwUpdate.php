<?php
	require 'includes/connect.php';
	require 'includes/varDef.php';

	$key=$_GET['key'];

	$un = stripslashes($un);
	$pw = stripslashes($pw);
	$un = mysql_real_escape_string($un);
	$pw = mysql_real_escape_string($pw);

	if($key){
		$sql="SELECT * FROM $tbl_name WHERE passwordKey='$key'";
		$result=mysql_query($sql);
		$count=mysql_num_rows($result);
		if($count==1){
			$message= "Please choose a NEW password for your account.";
			$array = mysql_fetch_array($result);
			$un=$array['un'];
			$id=$array["id"];
		}else{
			$message= "This page is no longer available!";
		}
	}else{
		$message= "This page is no longer available!";
	}

	if($id){
		mysql_query("UPDATE `$tbl_name` SET pw='$pw', passwordKey='none' WHERE id='$id';")or die(mysql_error("Database Error"));
		$message = "You have successfully updated your password, please click on the login button to log in to your account. \"";
	}


ob_end_flush();
?>
<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Password Update</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.css" />
	<link href="shaolinarts.min.css" rel="stylesheet" type="text/css" media="all" />
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.js"></script>
</head>
<body>
<form name="form1" method="post" action="pwUpdate.php"  data-ajax="false">
<div style="width: 500px; margin: 200px auto;" data-role="content">
		<div data-role="header">
			<h1>Password Update</h1>
		</div>
	    <ul data-role="listview" data-inset="true">
			<li>
			<?php echo $message; ?>
		</li>

		<?php
			if($count==1){
		?>
	        <li data-role="fieldcontain">
	            <label for="name" style="display: block; float: left; width: 100px;">Username:</label>
	            <?php echo "$un"; ?>
	        </li>
	        <li data-role="fieldcontain">
	            <label for="name" style="display: block; float: left; width: 100px;">Password:</label>
	            <input name="pw" type="password" id="mypassword"  data-mini="true" data-inline="true" />
			<input name="id" type="hidden" value="<?php echo $id; ?>" />
	        </li>
	        <li>
				<input type="submit" name="Submit" value="Submit"  data-mini="true" data-inline="true" data-icon="plus" />
			</li>
		<?php
			}
		?>
			<li><a href="http://shaolinarts.com/login.php" ajax="false">Back to the login page</a></li>
		</ul>
		</div>
		</form>
<script type="text/javascript">
	$(document).ready(function() {
		$('#myusername').focus();
	});
</script>
</body>
</html>
