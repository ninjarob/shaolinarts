<?php require 'includes/check_session.php'; ?>
<html>
<body>
	<br />
	<h1>Level 1</h1>
	<a href="Logout.php">Log Out</a>
</body> 
</html>