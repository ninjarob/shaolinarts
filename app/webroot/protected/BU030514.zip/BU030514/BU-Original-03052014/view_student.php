<?php
	require 'includes/check_session.php';
	$sessionRole = $_SESSION['sessionRole'];
	$sessionStudio = $_SESSION['sessionStudio'];
	require 'includes/roleCheck.php';
	require 'includes/connect.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Shaolin Arts</title>


<link href="p7curvitude/p7CRVboxes982_2col.css" rel="stylesheet" type="text/css" />
<link href="p7curvitude/p7CRV04.css" rel="stylesheet" type="text/css" />
<link href="p7pmm/p7PMMh13.css" rel="stylesheet" type="text/css" media="all" />




	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.css" />

	<link rel="stylesheet" href="validation/css/validationEngine.jquery.css" type="text/css"/>
	<link rel="stylesheet" href="validation/css/template.css" type="text/css"/>


	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.3.0-rc.1/jquery.mobile-1.3.0-rc.1.min.js"></script>

	<script type="text/javascript" src="p7pmm/p7PMMscripts.js"></script>


	<script src="validation/js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>
	<script src="validation/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>

<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#form1").validationEngine('attach');
		});
	</script>

<meta name="Keywords" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, Utah, Arizona, Marital Arts" />
<meta name="Description" content="Shaolin Arts is a family system of martial arts over 3,000 years old. Common western terms used to describe it would be Kung Fu, Tai Chi Chuan, Karate, Self Defense, Wushu, Animal Styles, Mixed Martial Arts, Chi Qi Gung or grappling. " />

<style type="text/css">

</style>




</head>
<body>
<div id="masthead" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, UtahArizonaMarital Arts">
  <div id="logo" content="Kung Fu, Tai Chi, Tai Chi Chuan, self defense, karate, fitness, sandy, UtahArizonaMarital Arts"><img src="images/logoanimbk.gif" alt="" width="982" height="160" /></div>
  <div id="navbar">
    <div id="navbar_inner">
      <div id="navbar_inner2">
<div id="p7PMM_1" class="p7PMMh13">
  <ul class="p7PMM">
    <li><a href="../index.html">Home</a></li>
    <li><a href="pages/class-information.html">Class Information</a></li>
    <li><a href="pages/locations.html">Locations</a></li>
    <li><a ajax="false" href="pages/faq.html" data-ajax="false">FAQ</a></li>
    <li><a href="pages/events.html">Current Events</a></li>
    <li><a href="pages/areas-of-study.html">Areas of Study</a>
      <div>
        <ul>
          <li><a href="pages/kung-fu.html">Kung Fu</a></li>
          <li><a href="pages/tai-chi.html">Tai Chi</a></li>
          <li><a href="pages/self-defense.html">Self Defense</a></li>
          <li><a href="pages/mma.html">Mixed Martial Arts</a></li>
          <li><a href="pages/fitness.html">Fitness</a></li>
        </ul>
      </div>
    </li>
    <li><a href="pages/information.html">More Information</a>
      <div>
        <ul>
          <li><a href="pages/about-us.html">About Shaolin Arts</a></li>
          <li><a href="pages/events.html">Current Events</a></li>
          <li><a href="pages/class-information.html">Class Information</a></li>
          <li><a href="pages/locations.html">Locations</a></li>
          <li><a ajax="false" href="pages/faq.html" data-ajax="false">FAQ</a></li>
          <li><a href="pages/contact.html">Contact Us</a></li>
          <li><a href="pages/history.html">History &amp; Philosophy</a></li>
        </ul>
      </div>
    </li>
     <li><a href="Logout.php">Log Out</a></li>
  </ul>
  <div class="p7pmmclearfloat">&nbsp;</div>
  <!--[if lte IE 6]>
<style>
.p7PMMh13 ul ul li {float:left; clear: both; width: 100%;}.p7PMMh13 {text-align: left;}.p7PMMh13, .p7PMMh13 ul ul a {zoom: 1;}
.p7PMMh13 ul ul {border: 1px solid #fff; background-color: #F90 !important;}
.p7PMMh13 ul ul a, .p7PMMh13 ul ul li {background-image: none !important;}
.p7PMMh13 ul ul a {padding: 6px 12px !important;}
.p7PMMh13 ul ul a:hover {background-color: #010101 !important;}
.p7PMMh13 ul ul a.trig_open {background-color: #000 !important; color: #fff;}
.p7PMMh13 ul ul a.trig_closed {background-image: url(p7pmm/img/pmm_east_dark.gif) !important; background-repeat: no-repeat; background-position: right center;}
</style>
<![endif]-->
  <!--[if IE 5]>
<style>.p7PMMh13, .p7PMMh13 ul ul a {height: 1%; overflow: visible !important;} .p7PMMh13 {width: 100%;}</style>
<![endif]-->
  <!--[if IE 7]>
<style>.p7PMMh13, .p7PMMh13 a{zoom:1;}.p7PMMh13 ul ul li{float:left;clear:both;width:100%;}</style>
<![endif]-->
  <script type="text/javascript">
<!--
P7_PMMop('p7PMM_1',1,1,-10,-20,0,0,0,1,0,3,1,1,0,0);
//-->
  </script>
</div>
<div class="clearfloat">&nbsp;</div>
      </div>
    </div>
  </div>
</div>
  <div class="c2_982" id="columnwrapper">
  <div id="columntop">&nbsp;</div>
  <div id="c1">
    <div class="content">
      <h2 class="topZero"><img src="images/Chuan-Fa-char-with-English.jpg" width="137" height="569" alt="chaun fa" /></h2>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p><img src="images/Chen-character-englishBlackGold.jpg" width="144" height="576" alt="chen tai chi chuan" /></p>
    </div>
  </div>
  <div id="c2">
    <div class="content">


<h1>View Student</h1>
<p style="margin-bottom: 20px;"><a href="admin.php"  data-role="button" data-mini="true" data-inline="true" data-icon="back" >Return to the admin tool</a></p>

<?php

	$id=$array["id"];
	$picture=$array["picture"];
	$name=$array["name"];
	$lastName=$array["lastName"];
	$homePhone=$array["homePhone"];
	$cellPhone=$array["cellPhone"];
	$workPhone=$array["workPhone"];
	$email=$array["email"];
	$addres=$array["addres"];
	$city=$array["city"];
	$state=$array["state"];
	$zip=$array["zip"];
	$birthday=$array["birthday"];
	$birthday = date("F d Y", strtotime($birthday));



	$spouseGuardian=$array["spouseGuardian"];
	$sgPhone=$array["sgPhone"];
	$sgCellPhone=$array["sgCellPhone"];

	$startDate=$array["startDate"];
	$startDate = date("F d Y", strtotime($startDate));
	$dueDate=$array["dueDate"];
	$dueDate = date("F d Y", strtotime($dueDate));


	$status=$array["status"];
	if($status==0){ $status= "Active";}
	if($status==1){ $status= "Not Active";}
	if($status==2){ $status= "Non Student";}

	$studio=$array["studio"];
	if($studio==1){ $studio= "Glendale, AZ";}
	if($studio==2){ $studio= "Sandy, UT";}
	if($studio==3){ $studio= "Taylorsville, UT";}
	if($studio==4){ $studio= "Sandy and Taylorsville,UT";}



	$rank=$array["rank"];
	if($rank==23) { $rank="Youth White";}
	if($rank==24) { $rank="Youth Yellow";}
	if($rank==25) { $rank="Youth Orange";}
	if($rank==26) { $rank="Youth Purple";}
	if($rank==27) { $rank="Youth Blue";}
	if($rank==28) { $rank="Youth Blue Advanced";}
	if($rank==29) { $rank="Youth Green";}
	if($rank==30) { $rank="Youth Green Advanced";}
	if($rank==31) { $rank="Youth Red";}
	if($rank==32) { $rank="Youth Brown";}
	if($rank==33) { $rank="Youth Brown Advanced";}
	if($rank==1) { $rank="White";}
	if($rank==2) { $rank="Yellow";}
	if($rank==3) { $rank="Orange";}
	if($rank==4) { $rank="Purple";}
	if($rank==5) { $rank="Blue";}
	if($rank==6) { $rank="Blue Advanced";}
	if($rank==7) { $rank="Green";}
	if($rank==8) { $rank="Green Advanced";}
	if($rank==9) { $rank="Red";}
	if($rank==10) { $rank="Brown";}
	if($rank==11) { $rank="Brown Advanced";}
	if($rank==12) { $rank="Sidi";}
	if($rank==13) { $rank="Sidi Dai Lou";}
	if($rank==14) { $rank="Si Hing";}
	if($rank==15) { $rank="Si Hing Dai Lou";}
	if($rank==16) { $rank="Sisuk";}
	if($rank==17) { $rank="Sisuk Dai Lou";}
	if($rank==18) { $rank="Sifu";}
	if($rank==19) { $rank="Si Bok";}
	if($rank==20) { $rank="Si Gung";}
	if($rank==21) { $rank="Si Tai Gung";}
	if($rank==22) { $rank="Si Jo";}


	$rankDate=$array["rankDate"];
	$rankDate = date("F d Y", strtotime($rankDate));

	$notes=$array["notes"];

	$longTermProgram=$array["longTermProgram"];
	if($longTermProgram==1){$longTermProgram="BPS";}
	if($longTermProgram==2){$longTermProgram="contract";}
	if($longTermProgram==3){$longTermProgram="3 Months";}
	if($longTermProgram==4){$longTermProgram="6 Month";}
	if($longTermProgram==5){$longTermProgram="12 Month";}
	if($longTermProgram==6){$longTermProgram="Month to Month";}

	$lessonType=$array["lessonType"];
	if($lessonType==1){$lessonType="Group";}
	if($lessonType==2){$lessonType="Private";}
	if($lessonType==3){$lessonType="Accelerated";}
	if($lessonType==4){$lessonType="BSP";}

	$taiChiStatus=$array["taiChiStatus"];
	if($taiChiStatus==0){ $taiChiStatus= "Active";}
	if($taiChiStatus==1){ $taiChiStatus= "Not Active";}
	if($taiChiStatus==2){ $taiChiStatus= "Non Student";}

	$taiChiStudio=$array["taiChiStudio"];
	if($taiChiStudio==1){ $taiChiStudio= "Glendale, AZ";}
	if($taiChiStudio==2){ $taiChiStudio= "Sandy, UT";}
	if($taiChiStudio==3){ $taiChiStudio= "Taylorsville, UT";}
	if($taiChiStudio==4){ $taiChiStudio= "Sandy and Taylorsville,UT";}


	$TaiChiRank=$array["TaiChiRank"];
	if($TaiChiRank==0) { $TaiChiRank= " White Sash";}
	if($TaiChiRank==5) { $TaiChiRank= " Youth Gold Sash";}
	if($TaiChiRank==6) { $TaiChiRank= " Youth Blue Sash";}
	if($TaiChiRank==7) { $TaiChiRank= " Youth Red Sash";}
	if($TaiChiRank==1) { $TaiChiRank= " Gold Sash";}
	if($TaiChiRank==2) { $TaiChiRank= " Blue Sash";}
	if($TaiChiRank==3) { $TaiChiRank= " Red Sash";}
	if($TaiChiRank==12) { $TaiChiRank= " Sidi";}
	if($TaiChiRank==13) { $TaiChiRank= " Sidi Dai Lou";}
	if($TaiChiRank==14) { $TaiChiRank= " Si Hing";}
	if($TaiChiRank==15) { $TaiChiRank= " Si Hing Dai Lou";}
	if($TaiChiRank==16) { $TaiChiRank= " Sisuk";}
	if($TaiChiRank==17) { $TaiChiRank= " Sisuk Dai Lou";}
	if($TaiChiRank==18) { $TaiChiRank= " Sifu";}
	if($TaiChiRank==19) { $TaiChiRank= " Si Bok";}
	if($TaiChiRank==20) { $TaiChiRank= " Si Gung";}
	if($TaiChiRank==21) { $TaiChiRank= " Si Tai Gung";}
	if($TaiChiRank==22) { $TaiChiRank= " Si Jo";}

	$TaiChiRankDate=$array["TaiChiRankDate"];
	$TaiChiRankDate = date("F d Y", strtotime($TaiChiRankDate));


	$TaiChiProgram=$array["TaiChiProgram"];
	if($TaiChiProgram==1){$TaiChiProgram="BPS";}
	if($TaiChiProgram==2){$TaiChiProgram="contract";}
	if($TaiChiProgram==3){$TaiChiProgram="3 Months";}
	if($TaiChiProgram==4){$TaiChiProgram="6 Months";}
	if($TaiChiProgram==5){$TaiChiProgram="12 Months";}
	if($TaiChiProgram==6){$TaiChiProgram="Month to Month";}


	$TaiChiLessonType=$array["TaiChiLessonType"];
	if($TaiChiLessonType==1){$TaiChiLessonType="Group";}
	if($TaiChiLessonType==2){$TaiChiLessonType="Private";}
	if($TaiChiLessonType==3){$TaiChiLessonType="Accelerated";}
	if($TaiChiLessonType==4){$TaiChiLessonType="BSP";}

	$studentID=$array["studentID"];

	$ice1=$array["ice1"];
	$ice1Phone=$array["ice1Phone"];
	$ice1CellPhone=$array["ice1CellPhone"];
	$ice2=$array["ice2"];
	$ice2Phone=$array["ice2Phone"];
	$ice2CellPhone=$array["ice2CellPhone"];
	$ice3=$array["ice3"];
	$ice3Phone=$array["ice3Phone"];
	$ice3CellPhone=$array["ice3CellPhone"];




?>
	<ul data-role="listview" data-inset="true">
		<?php if($picture){ ?>
			<li data-role="fieldcontain" style="text-align: center; padding: 30px;">
				<span><img src="upload/<?php echo "$picture"; ?>" style="width: 300px;" /></span>
			</li>
		<?php } ?>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Name:</label><span>
            <?php echo "$name $lastName"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Home Phone:</label><span>
            <?php echo "$homePhone"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Cell Phone:</label><span>
            <?php echo "$cellPhone"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Work Phone:</label><span>
            <?php echo "$workPhone"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">email:</label><span>
            <?php echo "$email"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Address:</label><span>
            <?php echo "$addres"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">City:</label><span>
            <?php echo "$city"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">State:</label><span>
            <?php echo "$state"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">ZIP:</label><span>
            <?php echo "$zip"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Birth Day:</label><span>
            <?php echo "$birthday"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Spouse / Guardan:</label><span>
            <?php echo "$spouseGuardian"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">S/G Phone:</label><span>
            <?php echo "$sgPhone"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">S/G Cell Phone:</label><span>
            <?php echo "$sgCellPhone"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Start Date:</label><span>
            <?php echo "$startDate"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Due Date:</label><span>
            <?php echo "$dueDate"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Kung Fu Status:</label><span>
            <?php echo "$status"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Kung Fu Studio:</label><span>
            <?php echo "$studio"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Kung Fu Program Term:</label><span>
            <?php echo "$longTermProgram"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Kung Fu Lesson Type:</label><span>
            <?php echo "$lessonType"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Kung Fu Rank:</label><span>
            <?php echo "$rank"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Kung Fu Rank Date:</label><span>
            <?php echo "$rankDate"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Tai Chi Status:</label><span>
            <?php echo "$taiChiStatus"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Tai Chi Studio:</label><span>
            <?php echo "$taiChiStudio"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Tai Chi Program Term:</label><span>
            <?php echo "$TaiChiProgram"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Tai Chi Lesson Type:</label><span>
            <?php echo "$TaiChiLessonType"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Tai Chi Rank:</label><span>
            <?php echo "$TaiChiRank"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Tai Chi Rank Date:</label><span>
            <?php echo "$TaiChiRankDate"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">ICE Name:</label><span>
            <?php echo "$ice1"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">ICE Phone:</label><span>
            <?php echo "$ice1Phone"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">ICE Cellphone:</label><span>
            <?php echo "$ice1CellPhone"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">ICE 2 Name:</label><span>
            <?php echo "$ice2"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">ICE 2 Phone:</label><span>
            <?php echo "$ice2Phone"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">ICE 2 Cellphone:</label><span>
            <?php echo "$ice2CellPhone"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">ICE 3 Name:</label><span>
            <?php echo "$ice3"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">ICE 3 Phone:</label><span>
            <?php echo "$ice3Phone"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">ICE 3 Cellphone:</label><span>
            <?php echo "$ice3CellPhone"; ?>&nbsp;</span>
		</li>
		<li data-role="fieldcontain">
            <label for="name" style="display: block; float: left; width: 220px;">Notes:</label><span>
            <?php echo "$notes"; ?>&nbsp;</span>
		</li>
	</ul>
	<p style="margin-bottom: 20px;"><a href="admin.php"  data-role="button" data-mini="true" data-inline="true" data-icon="back" >Return to the admin tool</a></p>


	</div>
  </div>
  <div id="columnbottom">&nbsp;</div>
</div>
<div id="footer">
  <div id="footercontent">
    <p class="footphone">(623) 581-2000 Glendale, AZ  • (801) 566-6364 Sandy, UT • (801) 967-2300 Taylorsville, UT<br />
    </p>
<p>&copy; Copyright 2010 Shaolin Arts, LLC. All Rights Reserved.</p>
  </div>
</div>


</body>
</html>


<?php ob_end_flush();?>


