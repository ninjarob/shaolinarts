<?php include 'includes/header.php'; ?>
<?php include 'includes/banner.php'; ?>
<?php include 'includes/navigation.php'; ?></div>
<div class="row corpus">
<div class="col-md-3 asideColumn hidden-xs hidden-sm">
	<aside class="contentCol">
		<h2>Upcoming Events</h2>

		<h4>Utah</h4>
		<p><strong>Kung Fu Review</strong><br/>
		Jan 24th 6 pm</p>

		<p><strong>Crane Test</strong><br/>
		Jan 18, 2 pm.</p>

		<s<p>trong>Chinese New Year</strong><br/>
		Jan 31st</p>

		<p><strong>Snake Test</strong><br/>
		March 22nd</p>

		<h4>Arizona</h4>

		<p><strong>Rank Review</strong><br/>
		Feb 22nd</p>

		<p><strong>Staff Clinic</strong><br/>
		March 8th</p>

		<p><strong>Rank Review</strong><br/>
		March 22nd</p>

		<p><strong>Tiger Test</strong><br/>
		April 5th</p>
	</aside>
</div>
<div class="col-md-9 sectionContent">
	<section class="contentCol">
<h2>Current Events</h2>
<h4>Crane Test</h4>
<p>The crane test, or clinic, is designed to teach and give practical experience with those skills related to the martial art style of the crane, namely balance, focus, long range movement and awareness. The crane test is for every student who would honestly like to learn more about the crane movements and methods. Individual skill level is not as important as an open mind, willingness to learn, experience and having a fun time.</p>
<p>Each animal test is offered only once a year so take advantage of this opportunity. The crane, snake, leopard and tiger test each must be completed before attempting the Dragon Test.</p>
<h2>2014 Year of the Horse</h2>
<p>The spirit of the horse is recognized to be the Chinese people’s ethos – making unremitting efforts to improve themselves. It is energetic, bright, warm-hearted, intelligent and able.</p>
<h4>5 Steps to Lasting Changes  </h4>
<p>by Mary Ellen Strote</p>
<p>1. Choose the right goal. Don’t get caught in the statement: I don’t know where I’m going but I’m making good time!</p>
<p>2. Slow down. Abrupt change seldom lasts. The way to accomplish change is to visualize your goal and weave it into your life, making small adjustments along the way.</p>
<p>3. Take All the Necessary Steps. We’re always trying to shortcut the process of change.  But it’s going through the process that gives us depth, alters our behavior and guarantees that change will last.</p>
<p>4. Enjoy the pursuit. If you think the changes you are making will guarantee happiness, you’re wrong. We’re raised to think of happiness as a goal, but happiness is a result, the consequence of doing the meaningful work.</p>
<p>5. Accept the Greater Challenge. Taking the quick and easy route through life deprives us of opportunities to develop character. It is in living all the seasons of our lives that we acquire knowledge and experience.</p>
<p>Time does not stand still for anyone. As the times change so too can you. </p>
<p>I find that the harder I work, the more luck I seem to have.    Thomas Jefferson</p>
<h2>Knowledge</h2>
<p>Knowledge is neutral; it has no will of its own. It is up to the individual to direct this knowledge into a productive channel.</p>
<p>As the famous Zen Master Gasanhas said:</p>
<p>A poor disciple utilizes a teacher’s influence.<br />
A fair disciple admires a teacher’s kindness.<br />
A good disciple grows strong under a teacher’s discipline.<br />
However, a teacher is but a student of his students.<br />
He is guided by each and every one of them.</p>
<p>Tai Chi  teaches us that there is another world, equally vast, and equally important ... the world within.</p>
<p>Hating is self-punishment.<br />Hosea Ballou</p>
<p>When people say they hate you for what you are, tell them that it feels better than being loved for what you are not.<br />Unknown</p>
	</section>
</div>
</div>
<?php include 'includes/footer.php'; ?>
<?php ob_end_flush();?>